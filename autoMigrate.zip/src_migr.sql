Rem 
Rem    NAME
Rem      src_migr.sql
Rem
Rem    DESCRIPTION
Rem      This script prepares the source database for migration either directly or by a process of continuous recovery.
Rem      Since the script must work on all Oracle versions >= 10, some of the code in unavoidably cumbersome - e.g. cannot use LISTAGG
Rem
Rem    COMMAND
Rem      sqlplus / as sysdba @src_migr.sql \
Rem         mode=[ANALYZE|EXECUTE|RESET|REMOVE|INCR-TS] \
Rem         incr-ts-dir=DIRECTORY_PATH \
Rem         incr-ts-freq="freq=hourly; byminute=0; bysecond=0;"
Rem
Rem      Full documentation at https://github.com/xsf3190/automigrate.git
Rem

WHENEVER SQLERROR EXIT

set serveroutput on size unlimited
set linesize 1000
set feedback off
set verify off
set echo off
set pagesize 0
set trimspool on

col 1 new_value 1
col 2 new_value 2
col 3 new_value 3
col 4 new_value 4

SELECT '' "1", '' "2", '' "3", '' "4" FROM dual WHERE 1=2;

set termout off
define 1
define 2
define 3
define 4
set termout on

variable p_ip_address   VARCHAR2(30)
variable p_dblink_user  VARCHAR2(30)
variable p_run_mode     VARCHAR2(20)
variable p_incr_ts_dir  VARCHAR2(100)
variable p_incr_ts_freq VARCHAR2(100)

spool src_migr_exec.sql

DECLARE
    TYPE DBLINK_USER_PRIVS IS TABLE OF VARCHAR2(50);

    l_privs DBLINK_USER_PRIVS:=DBLINK_USER_PRIVS(
        'SELECT ANY DICTIONARY',
        'SELECT ON SYS.USER$',
        'SELECT ON SYS.TRANSPORT_SET_VIOLATIONS',
        'CREATE SESSION',
        'ALTER TABLESPACE',
        'CREATE ANY DIRECTORY',
        'DROP ANY DIRECTORY',
        'CREATE ANY JOB',
        'MANAGE SCHEDULER',
        'EXECUTE ON SYS.DBMS_BACKUP_RESTORE',
        'EXECUTE ON SYS.DBMS_TTS',
        'EXECUTE ON SYS.DBMS_SYSTEM');
        
    l_privs_lt12 DBLINK_USER_PRIVS:=DBLINK_USER_PRIVS(
        'SELECT ON SYS.DEFAULT_PWD$',
        'SELECT ON SYS.KU_NOEXP_TAB',
        'SELECT ON SYSTEM.LOGSTDBY$SKIP_SUPPORT');        
    
    l_schema_exists BOOLEAN;
    l_version_lt_12 BOOLEAN;
    
    l_pw VARCHAR2(10):=DBMS_RANDOM.string('x',5)||DBMS_RANDOM.string('a',4)||'!';
    
    n PLS_INTEGER;
    -------------------------------
    PROCEDURE exec(pCommand IN VARCHAR2) IS
    BEGIN
        dbms_output.put_line(pCommand);  
    END;
    
    -------------------------------
    FUNCTION version(pVersion IN VARCHAR2 DEFAULT NULL) RETURN INTEGER IS
        l_version_tmp VARCHAR2(20):=pVersion;
        l_version INTEGER;
        l_dots INTEGER;
        n PLS_INTEGER;
    BEGIN
        IF (l_version_tmp IS NULL) THEN
            SELECT COUNT(*) INTO n FROM dual WHERE EXISTS (SELECT NULL FROM dba_tab_columns WHERE table_name='PRODUCT_COMPONENT_VERSION' AND owner='SYS' AND column_name='VERSION_FULL');
            IF (n=1) THEN
                EXECUTE IMMEDIATE 'SELECT MAX(version_full) FROM product_component_version' INTO l_version_tmp;
            ELSE
                EXECUTE IMMEDIATE 'SELECT MAX(version) FROM product_component_version WHERE product LIKE ''Oracle Database%''' INTO l_version_tmp;
            END IF;
        END IF;
        l_dots:=LENGTH(l_version_tmp)-LENGTH(REPLACE(l_version_tmp,'.'));
        FOR i IN l_dots..2 LOOP
            l_version_tmp:=l_version_tmp||'.0';
        END LOOP;
        SELECT SUM(v*POWER(10,n-1))
          INTO l_version
          FROM
              (
                SELECT REGEXP_SUBSTR(l_version_tmp,'[^.]+', 1, level) v, ROW_NUMBER() OVER (ORDER BY LEVEL DESC) n
                  FROM dual
                 WHERE level<=4
               CONNECT BY REGEXP_SUBSTR(l_version_tmp, '[^.]+', 1, level) IS NOT NULL
              );
        RETURN(l_version);
    END;
    
    -------------------------------
    PROCEDURE remove_backups(pDirectoryPath in dba_directories.directory_path%type) IS
        f utl_file.file_type;
        l_cmdfile VARCHAR2(50):='remove_backups.rman';
    BEGIN
        f:=utl_file.fopen(location=>'MIGRATION_FILES_1_DIR', filename=>l_cmdfile, open_mode=>'w', max_linesize=>32767);
        utl_file.put_line(f,'connect target /');
        utl_file.put_line(f,'DELETE NOPROMPT COPY TAG=''INCR-TS'';'); 
        utl_file.put_line(f,'DELETE NOPROMPT BACKUP TAG=''INCR-TS'';');
        utl_file.put_line(f,'exit');
        utl_file.fclose(f);
        dbms_output.put_line('host rman cmdfile='||pDirectoryPath||'/'||l_cmdfile||' log='||pDirectoryPath||'/'||l_cmdfile||'.log');
        EXCEPTION 
            WHEN OTHERS THEN 
                utl_file.fclose(f); 
                RAISE;
    END;
    
    -------------------------------
    PROCEDURE validate_params IS
        l_cdb VARCHAR2(3);
        l_compatibility VARCHAR2(20);
        l_oracle_pdb_sid VARCHAR2(50);
        l_this_version INTEGER;
        n PLS_INTEGER;
    BEGIN
        /*
         * MINIMUM DATABASE VERSION / COMPATIBILITY FOR XTTS - 10.1.0.3 / 10.0.0
         */
        l_this_version:=version();
        IF (l_this_version<version('10.1.0.3')) THEN
            RAISE_APPLICATION_ERROR(-20000,'MINIMUM DATABASE VERSION SUPPORTED FOR XTTS IS 10.1.0.3. USE CONVENTIONAL EXPORT/IMPORT');
        END IF;

        SELECT value INTO l_compatibility FROM v$parameter WHERE name='compatible';
        IF (version(l_compatibility)<version('10.0.0')) THEN
            RAISE_APPLICATION_ERROR(-20000,'MINIMUM COMPATIBILITY IS 10.0.0 - USE ALTER SYSTEM TO CHANGE, RESTART DATABASE AND RETRY.');
        END IF; 

        /*
         * MUST BE ARCHIVELOG TO MIGRATE USING INCREMENTAL BACKUP PROCESS 
         */
        IF (:p_run_mode='INCR-TS') THEN
            SELECT COUNT(*) INTO n FROM dual WHERE EXISTS (SELECT NULL FROM v$database WHERE log_mode='ARCHIVELOG');
            IF (n=0) THEN
                RAISE_APPLICATION_ERROR(-20000,'MUST BE ARCHIVELOG MODE TO MIGRATE USING INCREMENTAL BACKUPS');
            END IF;
        END IF; 

        /*
         * MUST BE RUNNING "MIGRATION" JOB TO FINALIZE INCREMENTAL BACKUP PROCESS 
         */
        IF (:p_run_mode='INCR-TS-FINAL') THEN
            SELECT COUNT(*) INTO n FROM dual WHERE EXISTS (SELECT NULL FROM dba_scheduler_jobs WHERE owner=:p_dblink_user AND job_name='MIGRATION_INCR');
            IF (n=0) THEN
                RAISE_APPLICATION_ERROR(-20000,'MUST BE RUNNING MIGRATION_INCR JOB');
            END IF;
        END IF; 

        /*
         * ABORT IF WE ARE CDB DATABASE AND ORACLE_PDB_SID HAS NOT BEEN SET
         */
        l_cdb:='NO';
        IF (l_this_version>version('12')) THEN
            EXECUTE IMMEDIATE 'SELECT cdb FROM v$database' INTO l_cdb;
        END IF;
        IF (l_cdb='YES') THEN
            sys.dbms_system.get_env('ORACLE_PDB_SID',l_oracle_pdb_sid);
            IF (l_oracle_pdb_sid IS NULL) THEN
                RAISE_APPLICATION_ERROR(-20000,'SET VARIABLE ORACLE_PDB_SID TO MIGRATE PDB WITH THIS UTILITY.');
            END IF;
        END IF;
    END;
 
    -------------------------------
    PROCEDURE setParameter(pParameter IN VARCHAR2) IS
        l_name  varchar2(20);
        l_value varchar2(100);
        l_error varchar2(500);
    BEGIN
        IF (pParameter IS NULL) THEN
            RETURN;
        END IF;

        l_name:=UPPER(SUBSTR(pParameter,1,INSTR(pParameter,'=')-1));
        IF (l_name<>'INCR-TS-DIR') THEN
            l_value:=UPPER(SUBSTR(pParameter,INSTR(pParameter,'=')+1));
        ELSE
            l_value:=SUBSTR(pParameter,INSTR(pParameter,'=')+1);
        END IF;

        CASE l_name
            WHEN 'USER' THEN
                :p_dblink_user:=l_value;
            WHEN 'MODE' THEN 
                IF (l_value IN ('ANALYZE','EXECUTE','REMOVE','RESET','INCR-TS','INCR-TS-FINAL')) THEN 
                    :p_run_mode:=l_value;
                ELSE
                    l_error:='INVALID VALUE FOR PARAMETER:'||l_name||' - MUST BE ONE OF [ANALYZE|EXECUTE|REMOVE|RESET|INCR-TS|INCR-TS-FINAL]';
                END IF;
            WHEN 'INCR-TS-DIR' THEN 
                :p_incr_ts_dir:=l_value;
            WHEN 'INCR-TS-FREQ' THEN 
                :p_incr_ts_freq:=l_value;
            ELSE 
                l_error:='INVALID PARAMETER: '||l_name;
        END CASE;

        IF (l_error IS NOT NULL) THEN
            RAISE_APPLICATION_ERROR(-20000,l_error);
        END IF;    
    END;  

-----
BEGIN
    /* 
     * SET VARIABLE DEFAULTS
     */
    :p_ip_address:=UTL_INADDR.get_host_address;
    :p_dblink_user:='MIGRATION';
    :p_run_mode:='ANALYZE';
    :p_incr_ts_freq:='freq=hourly;';
    
    setParameter('&1');
    setParameter('&2');
    setParameter('&3');
    setParameter('&4');
    
    exec('set feedback on');
    exec('set verify on');
    exec('set echo on');
    
    SELECT COUNT(*) INTO n FROM dual WHERE EXISTS (SELECT NULL FROM dba_users WHERE username=:p_dblink_user);
    l_schema_exists:=(n=1);
    
    IF (:p_run_mode='REMOVE') THEN
        exec('DROP USER '||:p_dblink_user||' CASCADE;');
        FOR C IN (SELECT directory_name, directory_path FROM dba_directories WHERE REGEXP_LIKE(directory_name,'MIGRATION_FILES_[1-9]+_DIR')) LOOP
            IF (C.directory_name='MIGRATION_FILES_1_DIR') THEN
                remove_backups(C.directory_path);
            END IF;
            exec('DROP DIRECTORY '||C.directory_name||';');
        END LOOP;
        dbms_output.put_line('EXIT');
        RETURN;
    END IF;
    
    validate_params;
              
    IF NOT (l_schema_exists) THEN
        exec('CREATE USER '||:p_dblink_user||' IDENTIFIED BY "'||l_pw||'" DEFAULT TABLESPACE SYSTEM QUOTA 10M ON SYSTEM;');
        
        FOR i IN 1..l_privs.COUNT LOOP
            exec('GRANT '||l_privs(i)||' TO '||:p_dblink_user||';');
        END LOOP;
        
        IF (version()>version('11')) THEN
            exec('GRANT DATAPUMP_EXP_FULL_DATABASE TO '||:p_dblink_user||';');
        ELSE
            exec('GRANT DATAPUMP_FULL_DATABASE TO '||:p_dblink_user||';');
        END IF;
        
        l_version_lt_12:=(version()<version('12'));
        IF (l_version_lt_12) THEN
            FOR i IN 1..l_privs_lt12.COUNT LOOP
                exec('GRANT '||l_privs_lt12(i)||' TO '||:p_dblink_user||';');
            END LOOP;              
        END IF;
        
        exec('ALTER SESSION SET CURRENT_SCHEMA='||:p_dblink_user||';');
        
        exec('CREATE TABLE MIGRATION_INIT AS SELECT '''||l_pw||''' password FROM DUAL;');
        
        exec(q'{CREATE OR REPLACE VIEW V_APP_TABLESPACES AS
                  SELECT tablespace_name, status, file_id, SUBSTR(file_name,1,pos-1) directory_name, SUBSTR(file_name,pos+1) file_name, enabled, bytes 
                  FROM
                    (
                    SELECT t.tablespace_name, t.status, f.file_id, f.file_name,INSTR(f.file_name,'/',-1) pos, f.bytes, v.enabled
                      FROM dba_tablespaces t, dba_data_files f, v$datafile v
                     WHERE t.tablespace_name=f.tablespace_name
                       AND v.file#=f.file_id
                       AND t.contents='PERMANENT'
                       AND t.tablespace_name NOT IN ('SYSTEM','SYSAUX')
                       );}');
                       
        IF (l_version_lt_12) THEN
            /*
             *  SIMULATE "oracle_maintained" FIELD IN DBA_USERS IF VERSION <12. NEED THIS TO GRANT PRIVILEGES TO SYS-OWNED OBJECTS 
             */
            exec(q'{CREATE OR REPLACE VIEW V_MIGRATION_USERS AS
                      WITH u AS
                      (
                        SELECT username,no_expdp,no_sby,default_password
                        FROM dba_users 
                        LEFT OUTER JOIN (SELECT DISTINCT name username,'Y' no_expdp FROM sys.ku_noexp_tab WHERE obj_type='SCHEMA') 
                         USING(username)
                        LEFT OUTER JOIN (SELECT DISTINCT name username,'Y' no_sby FROM system.logstdby$skip_support WHERE action IN (0,-1))
                         USING(username)
                        LEFT OUTER JOIN (SELECT DISTINCT user_name username,'Y' default_password FROM sys.default_pwd$)
                         USING(username)
                      )
                      SELECT username, DECODE(COALESCE(no_expdp,no_sby,default_password),NULL,'N','Y') oracle_maintained
                      FROM u;}'); 
        ELSE
            exec('CREATE OR REPLACE VIEW V_MIGRATION_USERS AS
                      SELECT username, oracle_maintained FROM dba_users;');                 
        END IF;                       
        
        exec(q'{CREATE TABLE migration_ts(
                    file# NUMBER, 
                    bytes NUMBER, 
                    enabled VARCHAR2(10), 
                    from_scn NUMBER, 
                    tablespace_name VARCHAR2(30), 
                    pre_migr_status VARCHAR2(10), 
                    created DATE DEFAULT SYSDATE, 
                    updated DATE, 
                    transferred DATE, 
                    applied DATE, 
                    CONSTRAINT pk_migration_ts PRIMARY KEY(file#) );}');
    END IF;
    
    /*
     *  ALWAYS COMPILE PACKAGE UNTIL PROCESS STABILIZES
     */
    exec('ALTER SESSION SET CURRENT_SCHEMA='||:p_dblink_user||';');
    exec('set echo off');
    exec('@@pck_migration_src');
    exec('set echo on');
    exec('show errors');
        
    exec('spool src_migr.log');
    exec('exec '||:p_dblink_user||'.pck_migration_src.init_migration(p_ip_address=>:p_ip_address,p_run_mode=>:p_run_mode, p_incr_ts_dir=>:p_incr_ts_dir, p_incr_ts_freq=>:p_incr_ts_freq)');
    
    IF (:p_run_mode IN ('EXECUTE','INCR-TS-FINAL')) THEN
        FOR C IN (SELECT object_name FROM dba_objects WHERE object_type='SYNONYM' AND owner='PUBLIC' AND object_name='DBA_RECYCLEBIN') LOOP
            exec('PURGE DBA_RECYCLEBIN;');
        END LOOP;
    END IF;
    
    exec('spool off');
    exec('EXIT');
END;
/

spool off

@@src_migr_exec.sql
