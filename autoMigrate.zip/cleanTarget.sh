#!/bin/bash

SCRIPT=$(basename $0); FN="${SCRIPT%.*}"; LOGFILE=${FN}.log; SQLFILE=${FN}.sql; CD=$(pwd)

exec > >(tee ${LOGFILE}) 2>&1

export TNS_ADMIN="${CD}"

TNSNAMES="${TNS_ADMIN}/tnsnames.ora"; [[ -f "${TNSNAMES}" ]] && rm "${TNSNAMES}"
SQLNET="${TNS_ADMIN}/sqlnet.ora"; [[ -f "${SQLNET}" ]] && rm "${SQLNET}"
WALLET="${TNS_ADMIN}/wallet"; [[ -d "${WALLET}" ]] &&  rm -r "${WALLET}"

sqlplus /nolog<<EOF
    CONNECT / AS SYSDBA
    SET SERVEROUTPUT ON
    WHENEVER SQLERROR CONTINUE
    DROP USER C##MIGRATION CASCADE;
    EXIT
EOF

exit
