#!/bin/bash

SCRIPT=$(basename $0); FN="${SCRIPT%.*}"; LOGFILE=${FN}.log; SQLFILE=${FN}.sql; CD=$(pwd)

exec > >(tee ${LOGFILE}) 2>&1

export TNS_ADMIN="${CD}"

rm -v -r "${TNS_ADMIN}/wallet"
rm -v "${TNS_ADMIN}/tnsnames.ora" "${TNS_ADMIN}/sqlnet.ora" "${TNS_ADMIN}/runMigration.PDB1.*" 

sqlplus /nolog<<EOF
    CONNECT / AS SYSDBA
    SET SERVEROUTPUT ON
    WHENEVER SQLERROR CONTINUE
    DROP USER C##MIGRATION CASCADE;
    WHENEVER SQLERROR EXIT FAILURE
    DECLARE
        PROCEDURE executeIt(pCommand IN VARCHAR2) IS
        BEGIN
            dbms_output.put('About to '||pCommand);
            EXECUTE IMMEDIATE pCommand;
            dbms_output.put_line(' ... OK');
            EXCEPTION WHEN OTHERS THEN
                dbms_output.put_line(' ... FAILED'); RAISE;
        END;
    BEGIN
        FOR C IN (SELECT name, open_mode FROM v\$containers WHERE con_id>2) LOOP
            IF (C.open_mode='READ WRITE') THEN
                executeIt('ALTER PLUGGABLE DATABASE '||C.name||' CLOSE IMMEDIATE');
            END IF;
            executeIt('DROP PLUGGABLE DATABASE '||C.name||' INCLUDING DATAFILES');
            FOR C1 IN (SELECT job_name FROM dba_scheduler_jobs WHERE job_name LIKE '%'||C.name) LOOP
                DBMS_SCHEDULER.DROP_JOB(C1.job_name,TRUE);
            END LOOP;            
        END LOOP;
    END;
    /
    EXIT
EOF

exit
