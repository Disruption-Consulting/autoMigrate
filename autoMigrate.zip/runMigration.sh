#!/bin/bash

#####################################################################################################################################
#
#  SCRIPT        : runMigration.sh
#
#  DESCRIPTION   : Migrates a NON-CDB Oracle database (SOURCE) to version 19 PDB (TARGET)
#
#  INSTALL       : Install this script and relevant package sql files in an installation directory (e.g. "/tmp/migrate")
#
#
#  SOURCE DATABASE
#                       
#                ./runMigration -m [ANALYZE|EXECUTE|INCR] -b [BKPDIR] -f [BKPFREQ] -r -u [USER] -o [ORACLE_SID]
#
#                -m ANALYZE
#                     reports on database properties that are relevant to migration (e.g. size, version)
#                   EXECUTE
#                     prepares database for migration by setting application tablespaces to read only
#                   INCR
#                     starts background job to create incremental backups of application tablespace datafiles
#
#                -b BKPDIR
#                     for INCR specifies location of backup directory
#
#                -f BKPFREQ
#                     for INCR specifies backup frequency. Default is hourly.
#
#                -o ORACLE_SID
#                     identifies the SOURCE Oracle database to be migrated
#
#                -r removes the schema created to manage the migration and any incremental backups
#
#                -u USER
#                     required only if pre-migration database happens to have a user called "MIGRATION19"
#
#                OUTPUT
#                  log file "runMigration.log" including the command to be run on the TARGET database if -m [EXECUTE|INCR]
#                   
#
#  TARGET DATABASE
#                       
#                ./runMigration -c [CREDENTIAL] -t [TNS] -p [PDB} -o [ORACLE_SID] -r
#
#                -c CREDENTIAL
#                     credentials of migration schema created on SOURCE database.
#
#                -t TNS
#                     TNS string defining location of source database
#
#                -p PDB
#                     Name of the PDB to be created for the migration. Typically the SOURCE database name.
#
#                -o ORACLE_SID
#                     identifies the TARGET CDB database into which the SOURCE database will be migrated
#
#                -r removes the named PDB permanently including any data files
# 
#                -1 suppress gathering statistics of migrated PDB
#
#                -2 force use of Transportable Tablespace migration method (only for me to test vesion 10 migrations) 
#
#                -z create zip file autoMigrate.zip comprising source files in current directory
#
#                OUTPUT
#                  log file "runMigration.log" of tasks performed to create the target PDB
#                  for each PDB creates a log file "runMigration.PDB.log" of the transfer / datapump / post-migration tasks
#
#
#  SECURITY
#                The credentials of all schemas created by the script are stored in an external Oracle password wallet
#                created in the installation directory
#
#                Passwords are complex, randomly generated 10-character strings comprising upper/lower and special characters
#
#                Log files are loaded into the TARGET PDB and deleted from the OS file system when migration is completed
#
#####################################################################################################################################


usageSource() {
    echo "Usage: $0 [ -m MODE ] [ - u USER ] [ -b BKPDIR ] [ -f BKPFREQ ]"
    exit 1
}

usageTarget() {
    echo "Usage: $0 [ -c CREDENTIAL ] [ - t TNS ] [ -p PDB ]"
    exit 1
}

upper() {
    local UPPER=$(echo "${1}" | tr '[:lower:]' '[:upper:]')
    echo ${UPPER}
}

password() {
    local PW=$(cat /dev/urandom | tr -cd "a-zA-Z0-9@#%^*()_+?><~\`;" | head -c 10)
    echo \"${PW}\"
}

version() {
    local a b c d V="$@"
    IFS=. read -r a b c d <<< "${V}"
    echo "$((a * 10 ** 3 + b * 10 ** 2 + c * 10 + d))"
}

log() {
    echo -e "${1//?/${2:-=}}\n$1\n${1//?/${2:-=}}";
}


chkerr() {
    [[ "$1" != 0 ]] && { echo -n "ERROR at line ${2}: "; echo "${3}"; exit 1; }
}

#################################################################################
#
#  function: runsql
#
#  - run either the SQL passed in "-s" argument OR in file ${SQLFILE}
#  - "-v" argument returns result to STDOUT enabling ot to be captured in variable 
#  - default CONNECT string only applies for "-s"
#################################################################################
runsql() {
    local OPTIND
    local SQL
    local RETVAL=FALSE
    local SILENT
    
    while getopts "s:v" o; do
        case "${o}" in
            s) SQL=${OPTARG} ;;
            v) RETVAL=TRUE ;;
        esac
    done
    
    if [ -n "${SQL}" ]; then
        echo -e "CONNECT ${CONNECT}\n${SQL}">${SQLFILE}
    fi
    
    if [ "${RETVAL}" = "FALSE" ]; then
        echo -e "WHENEVER SQLERROR EXIT FAILURE\nSET ECHO ON\n$(cat ${SQLFILE})\nCOMMIT;\nEXIT" > ${SQLFILE}
    else
        echo -e "WHENEVER SQLERROR EXIT FAILURE\nSET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF\n$(cat ${SQLFILE})\nCOMMIT;\nEXIT" > ${SQLFILE}
        SILENT="-silent"
    fi    
    
    sqlplus ${SILENT} /nolog @${SQLFILE} || { return 1; }
}


#################################################################################
#
#  function: createWallet
#
#  - create wallet for external password store. 
#  - store randomly generated wallet password in migration_log table
#  - configure sqlnet.ora to enable use of External password store
#################################################################################
createWallet() {
    log "createWallet - ${WALLET}" 
    
    local WPW=$(password)
    mkstore -wrl "${WALLET}" -create<<-EOF
${WPW}
${WPW}
EOF

    runsql -s "INSERT INTO ${USER}.migration_log(id, name, log_message) VALUES (${USER}.migration_log_seq.nextval,'WPW','${WPW}');"
    chkerr "$?" "${LINENO}" "${VERSION}"
    
    cat <<EOF>${SQLNET}
WALLET_LOCATION = (SOURCE = (METHOD = FILE)(METHOD_DATA =(DIRECTORY = ${WALLET})))
SQLNET.WALLET_OVERRIDE = TRUE
EOF
}


#################################################################################
#
#  function: createCredential
#
#  - append entry for credential in tnsnames.ora
#  - when credential has alias $ORACLE_SID set CONNECT global variable
#################################################################################
createCredential() {
    log "createCredential - ALIAS:${1} USER: ${2} SERVICE: ${4}"
    
    [[ ! -d "${WALLET}" ]] && createWallet
    
    local TNS="${1}"
    local USR="${2}"
    local PWD="${3}"
    local SVC="${4}"
    
    local WPW=$(runsql -v -s "SELECT log_message FROM ${USER}.migration_log WHERE name='WPW';")
    chkerr "$?" "${LINENO}" "${WPW}"
    
    mkstore -wrl "${WALLET}" -createCredential "${TNS}" "${USR}" "${PWD}"<<EOF
${WPW}
EOF

    log "Check entry for ${TNS} exists in ${TNSNAMES}"
    #local EXISTS=$(grep "^${TNS}" "${TNSNAMES}"|wc -l)
    #[[ "${EXISTS}" = "0" ]] && cat <<EOF>>${TNSNAMES}
    cat <<EOF>>${TNSNAMES}
${TNS}=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=${SVC})))
EOF

    # Set default CONNECT string as soon as credential for ORACLE_SID created
    #
    [[ "${TNS}" = "${ORACLE_SID}" ]] && CONNECT="/@${TNS}"
}


#################################################################################
#
#  function: deleteCredential
#
#  - delete credential from wallet
#  - remove entry for credential from tnsnames.ora
#################################################################################
deleteCredential() {
    log "deleteCredential - ${1}"
    
    local TNS="${1}"
    
    local WPW=$(runsql -v -s "SELECT log_message FROM ${USER}.migration_log WHERE name='WPW';")
    chkerr "$?" "${LINENO}" "${WPW}"
    
    mkstore -wrl "${WALLET}" -deleteCredential "${TNS}"<<EOF
${WPW}
EOF

    sed -i "/^${TNS}/d" ${TNSNAMES}
}

#################################################################################
# Remove objects created to enable autoMigration on SOURCE database
#
# - restore tablespace pre-migration status
# - drop the schema - default name is MIGRATION19
# - drop directories created with name like MIGRATION19
# - remove any incremental RMAN backups
# - remove wallet and its enabling network configuration files
#################################################################################
removeSource() {
    log "removeSource"
    
    cat <<-EOF>${SQLFILE}
        CONNECT / AS SYSDBA
        WHENEVER SQLERROR EXIT FAILURE
        SET SERVEROUTPUT ON
        SET ECHO ON
        EXEC ${USER}.pck_migration_src.set_ts_readwrite
        DROP USER ${USER} CASCADE;
        DECLARE
            PROCEDURE exec(pCommand IN VARCHAR2) IS
            BEGIN
                dbms_output.put(pCommand);
                EXECUTE IMMEDIATE pCommand;
                dbms_output.put_line(' ..OK');
                EXCEPTION WHEN OTHERS THEN
                    dbms_output.put_line(' ..FAILED');
                    RAISE;
            END;
        BEGIN
            FOR C IN (SELECT directory_name FROM dba_directories WHERE directory_name LIKE '${USER}_%_DIR') LOOP
                exec('DROP DIRECTORY '||C.directory_name);
            END LOOP;
        END;
        /
EOF
    runsql || { echo "SQL FAILED"; exit 1; }
    
    local RMANFILE="${CD}/${FN}.rman"
    cat <<-EOF>${RMANFILE}
        CONNECT TARGET /
        DELETE NOPROMPT COPY TAG='INCR-TS'; 
        DELETE NOPROMPT BACKUP TAG='INCR-TS';
        EXIT
EOF
    rman cmdfile="${RMANFILE}" || { echo "RMAN DELETE INCREMENTAL MIGRATION BACKUPS FAILED"; exit 1; }
    
    deleteCredential "${ORACLE_SID}" 
}


createSourceSchema(){
    log "createSourceSchema"
    
    local PW=$(password)
    local V11=$(version "11")
    local V12=$(version "12")
    local THISDB=$(version "${VERSION}")
    local PRIV
    
    [[ ${THISDB} < ${V11} ]] && PRIV=EXP_FULL_DATABASE || PRIV=DATAPUMP_EXP_FULL_DATABASE

    cat <<-EOF>${SQLFILE}
        CONNECT / AS SYSDBA
        SET SERVEROUTPUT ON
        CREATE USER ${USER} IDENTIFIED BY ${PW} DEFAULT TABLESPACE SYSTEM QUOTA 10M ON SYSTEM;
        GRANT SELECT ANY DICTIONARY,
              CREATE SESSION,
              ALTER TABLESPACE,
              CREATE ANY JOB,
              CREATE ANY DIRECTORY,
              MANAGE SCHEDULER,
              DROP ANY TABLE,
              ${PRIV} TO ${USER};
        GRANT EXECUTE ON SYS.DBMS_BACKUP_RESTORE TO ${USER};
        GRANT EXECUTE ON SYS.DBMS_SYSTEM TO ${USER};
        GRANT EXECUTE ON SYS.DBMS_CRYPTO TO ${USER};

        CREATE OR REPLACE DIRECTORY ${USER}_SCRIPT_DIR AS '${CD}';
        GRANT READ, WRITE ON DIRECTORY ${USER}_SCRIPT_DIR TO ${USER};
        
        COL IP NEW_VALUE IP NOPRINT
        SELECT UTL_INADDR.get_host_address IP FROM DUAL;
        
        ALTER SESSION SET CURRENT_SCHEMA=${USER};
        CREATE OR REPLACE VIEW V_APP_TABLESPACES AS
          SELECT t.platform_id, t.tablespace_name, t.status, t.file_id, d.directory_path, d.directory_name, SUBSTR(t.file_name,pos+1) file_name, t.enabled, t.bytes
          FROM
            (
             SELECT d.platform_id, t.tablespace_name, t.status, f.file_id, f.file_name,INSTR(f.file_name,'/',-1) pos, f.bytes, v.enabled
               FROM dba_tablespaces t, dba_data_files f, v\$datafile v, v\$database d
              WHERE t.tablespace_name=f.tablespace_name
                AND v.file#=f.file_id
                AND t.contents='PERMANENT'
                AND t.tablespace_name NOT IN ('SYSTEM','SYSAUX')
            ) t, all_directories d
          WHERE d.directory_path(+)=SUBSTR(t.file_name,1,pos-1)
            AND d.directory_name(+) LIKE '${USER}_FILES%';
            
        CREATE TABLE migration_ts(
                    file# NUMBER,
                    bytes NUMBER,
                    enabled VARCHAR2(10),
                    from_scn NUMBER,
                    tablespace_name VARCHAR2(30),
                    pre_migr_status VARCHAR2(10),
                    created DATE DEFAULT SYSDATE,
                    updated DATE,
                    transferred DATE,
                    applied DATE,
                    CONSTRAINT pk_migration_ts PRIMARY KEY(file#));
                    
        CREATE SEQUENCE migration_log_seq START WITH 1 INCREMENT BY 1;

        CREATE TABLE migration_log(
    			 id NUMBER,
                 name VARCHAR2(10),
    			 log_time DATE DEFAULT SYSDATE,
    			 log_message CLOB,
    			 CONSTRAINT PK_MIGRATION_LOG PRIMARY KEY(id));
                 
        INSERT INTO migration_log(id, name, log_message) VALUES (migration_log_seq.nextval,'PW','${PW}');
        INSERT INTO migration_log(id, name, log_message) VALUES (migration_log_seq.nextval,'IP','&IP');
        COMMIT;
EOF

    if [[ ${THISDB} < ${V12} ]]; then
        cat <<-EOF>>${SQLFILE}
            GRANT SELECT ON SYS.KU_NOEXP_TAB  TO ${USER};
            GRANT SELECT ON SYSTEM.LOGSTDBY\$SKIP_SUPPORT TO ${USER};    
            CREATE OR REPLACE VIEW V_MIGRATION_USERS AS
              WITH u AS
              (
                SELECT username,no_expdp,no_sby,no_hc
                FROM dba_users
                LEFT OUTER JOIN (SELECT DISTINCT name username,'Y' no_expdp FROM sys.ku_noexp_tab WHERE obj_type='SCHEMA')
                 USING(username)
                LEFT OUTER JOIN (SELECT DISTINCT name username,'Y' no_sby FROM system.logstdby\$skip_support WHERE action IN (0,-1))
                 USING(username)
                LEFT OUTER JOIN (SELECT column_value as username, 'Y' no_hc FROM TABLE(sys.OdciVarchar2List(
                'APEX_PUBLIC_USER', 'FLOWS_FILES', 'FLOWS_020100', 'FLOWS_030100','FLOWS_040100',
                'OWBSYS_AUDIT', 'SPATIAL_CSW_ADMIN_USR', 'SPATIAL_WFS_ADMIN_USR','TSMSYS')))
                 USING(username)
              )
              SELECT username, DECODE(COALESCE(no_expdp,no_sby,no_hc),NULL,'N','Y') oracle_maintained
              FROM u;
EOF
    else
        cat <<-EOF>>${SQLFILE}
            CREATE OR REPLACE VIEW V_MIGRATION_USERS AS SELECT username, oracle_maintained FROM dba_users;
EOF
    fi
    
    cat <<-EOF>>${SQLFILE}
    PROMPT "COMPILING PCK_MIGRATION_SRC"
    set echo off
    @@pck_migration_src.sql
    set echo on
    show errors
    BEGIN
        EXECUTE IMMEDIATE 'ALTER PACKAGE PCK_MIGRATION_SRC COMPILE';
        EXCEPTION WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20000,'COMPILE FAILED');
    END;
    /
EOF
    
    runsql || { echo "createSourceSchema FAILED"; exit 1; }
    
    local SERVICE=$(runsql -v -s "SELECT ${USER}.pck_migration_src.getdefaultservicename FROM dual;")
    chkerr "$?" "${LINENO}" "${SERVICE}"
    
    createCredential "${ORACLE_SID}" "${USER}" "${PW}" "${SERVICE}" 
}


runSourceMigration() {
    log "runSourceMigration"

    cat <<-EOF>${SQLFILE}
    CONNECT ${CONNECT}
    SET SERVEROUTPUT ON
    SET LINESIZE 300
    BEGIN
        pck_migration_src.init(
            p_run_mode=>'${MODE}', 
            p_incr_ts_dir=>'${BKPDIR}', 
            p_incr_ts_freq=>NVL('${BKPFREQ}','freq=hourly;'));
    END;
    /
EOF
    runsql || { echo "runSourceMigration FAILED"; exit 1; }
}


processSource() {
    log "processSource"
    
    local V10103=$(version "10.1.0.3")
    local THISDB=$(version "${VERSION}")
    
    [[ "${MODE}" =~ (^ANALYZE|EXECUTE|INCR$) ]] || { echo "-m <MODE> MUST BE ONE OF [ANALYZE|EXECUTE|INCR]. DEFAULT IS ANALYZE."; exit 1; }
    [[ "${MODE}" = "INCR"  &&  ! -d "${BKPDIR}" ]] && { echo "-b <BKPDIR> VALID DIRECTORY MUST BE SPECIFIED FOR -m INCR"; exit 1; }
    [[ "${MODE}" != "INCR"  &&  (-n "${BKPDIR}" || -n "${BKPFREQ}") ]] && { echo "-b <BKPDIR> AND -f <BKPFREQ> ONLY RELEVANT FOR -m INCR"; exit 1; }
    [[ "${THISDB}" < "${V10103}" ]] && { echo "LOWEST VERSION WE CAN AUTO-MIGRATE IS 10.1.0.3"; exit 1; }
    
    if [ -n "${BKPDIR}" ]; then
        local BYTESORA=$(runsql -v -s "SELECT SUM(bytes) FROM dba_tablespaces t, dba_data_files f WHERE t.tablespace_name=f.tablespace_name AND t.contents='PERMANENT' AND t.tablespace_name NOT IN ('SYSTEM','SYSAUX');")
        local BYTESFS=$(df -k "${BKPDIR}" | tail -1 | awk '{print $4*1024}')
        [[ "${BYTESFS}" < "${BYTESORA}" ]] && { echo "-b <BKPDIR> NEEDS AT LEAST ${BYTESORA}. CURRENT CAPACITY IS ${BYTESFS}"; exit 1; }
    fi
    
    cat <<-EOF>${SQLFILE}
    CONNECT ${CONNECT}
    SET SERVEROUTPUT ON
    SET ECHO OFF
    DECLARE
        n PLS_INTEGER;
        l_compatibility VARCHAR2(10);
        l_cdb VARCHAR2(3);
        l_oracle_pdb_sid VARCHAR2(20);
    BEGIN
        n:=0;
        FOR C IN (SELECT DISTINCT file_name,nb,GT2TB FROM 
                    (SELECT file_name,COUNT(*) OVER (PARTITION BY file_name) nb, CASE WHEN bytes>2*POWER(1024,4) THEN 1 ELSE 0 END GT2TB
                       FROM(
                          SELECT SUBSTR(f.file_name,INSTR(f.file_name,'/',-1)+1) file_name, bytes
                            FROM dba_tablespaces t, dba_data_files f
                           WHERE t.tablespace_name=f.tablespace_name
                             AND t.contents='PERMANENT'
                             AND t.tablespace_name NOT IN ('SYSTEM','SYSAUX')
                        )
                 ) ) 
        LOOP
            IF (C.nb>1) THEN
                n:=n+1;
                dbms_output.put_line(C.file_name||' IN MULTIPLE DIRECTORIES. MUST BE RENAMED TO BE UNIQUE WITHIN DATABASE.');
            END IF;
            IF (C.GT2TB>0) THEN
                n:=n+1;
                dbms_output.put_line(C.file_name||' EXCEEDS MAXIMUM SIZE ALLLOWED 2TB.');
            END IF;
        END LOOP;
        
        SELECT value INTO l_compatibility FROM v\$parameter WHERE name='compatible';
        IF (l_compatibility LIKE '9%') THEN
            n:=n+1;
            dbms_output.put_line('MINIMUM COMPATIBILITY IS 10.0.0 - USE ALTER SYSTEM TO CHANGE, RESTART DATABASE AND RETRY.');
        END IF;
        
        IF ('${MODE}'='INCR') THEN
            FOR C IN (SELECT NULL FROM v\$database WHERE log_mode<>'ARCHIVELOG') LOOP
                n:=n+1;
                dbms_output.put_line('MUST BE ARCHIVELOG MODE TO MIGRATE USING INCREMENTAL BACKUPS.');
            END LOOP;
        END IF;                
        
        l_cdb:='NO';
        IF ('${VERSION}' LIKE '12%') THEN
            EXECUTE IMMEDIATE 'SELECT cdb FROM v\$database' INTO l_cdb;
        END IF;
        IF (l_cdb='YES') THEN
            sys.dbms_system.get_env('ORACLE_PDB_SID',l_oracle_pdb_sid);
            IF (l_oracle_pdb_sid IS NULL) THEN
                n:=n+1;
                dbms_output.put_line('SET ORACLE ENVIRONMENT VARIABLE "ORACLE_PDB_SID" TO MIGRATE PDB WITH THIS UTILITY.');
            END IF;
        END IF;        
        
        IF (n>0) THEN
            RAISE_APPLICATION_ERROR(-20000,n||' QUALIFICATION ERROR(S) OCCURED');
        END IF;
    END;
    /
EOF
    runsql || { echo "DATABASE DOES NOT QUALIFY FOR MIGRATION WITH THIS UTILITY"; exit 1; }    
    
    
    [[ "${REMOVE}" = "TRUE" ]] && { removeSource; exit 0; }
    
    local EXISTS=$(runsql -v -s "SELECT TO_CHAR(COUNT(*)) FROM dual WHERE EXISTS (SELECT 1 FROM dba_users WHERE username='${USER}');")
    chkerr "$?" "${LINENO}" "${EXISTS}"
    
    [[ "${EXISTS}" = "0" ]] && { createSourceSchema; runSourceMigration; } || runSourceMigration
}



#################################
#
#    TARGET MIGRATION PROCESS
#
#################################

createCommonUser() {
    log "createCommonUser"
    
    local CPW=$(password)
    
    cat <<-EOF>${SQLFILE}
        CONNECT / AS SYSDBA
        CREATE USER ${USER} IDENTIFIED BY ${CPW} DEFAULT TABLESPACE SYSTEM QUOTA 1M ON SYSTEM;
        GRANT ALTER SESSION,
              CREATE DATABASE LINK,
              CREATE ANY DIRECTORY,
              CREATE JOB,
              CREATE PLUGGABLE DATABASE,
              CREATE SESSION,
              MANAGE SCHEDULER,
              SET CONTAINER TO ${USER};
        ALTER USER ${USER} ADD CONTAINER_DATA = (CDB\$ROOT,PDB\$SEED) CONTAINER=CURRENT;
        GRANT SYSDBA TO ${USER} CONTAINER=ALL;
        GRANT EXECUTE ON SYS.DBMS_FILE_TRANSFER TO ${USER};
        GRANT EXECUTE ON SYS.DBMS_BACKUP_RESTORE TO ${USER};
        GRANT SELECT ON SYS.CDB_DATA_FILES TO ${USER};
        GRANT SELECT ON SYS.CDB_DIRECTORIES TO ${USER};
        GRANT SELECT ON SYS.CDB_PDBS TO ${USER};
        GRANT SELECT ON SYS.V_\$PDBS TO ${USER};
        ALTER SESSION SET CURRENT_SCHEMA=${USER};
        CREATE TABLE migration_ts
                       ("PDB_NAME"          VARCHAR2(128),
                        "TABLESPACE_NAME"   VARCHAR2(30),
                        "ENABLED"           VARCHAR2(20),
                        "PLATFORM_ID"       NUMBER,
                        "FILE_ID"           NUMBER,
                        "FILE_NAME"         VARCHAR2(100),
                        "DIRECTORY_NAME"    VARCHAR2(30),
                        "FILE_NAME_RENAMED" VARCHAR2(107),
                        "MIGRATION_STATUS"  VARCHAR2(50) DEFAULT 'TRANSFER NOT STARTED',
                        "START_TIME"        DATE,
                        "ELAPSED_SECONDS"   NUMBER,
                        "BYTES"             NUMBER,
                        "TRANSFERRED_BYTES" NUMBER,
                       CONSTRAINT PK_MIGRATION_TS PRIMARY KEY(PDB_NAME,FILE_ID));
        CREATE TABLE migration_bp
                       ("PDB_NAME"          VARCHAR2(128),
                        "RECID"             NUMBER,
                        "FILE_ID"           NUMBER,
                        "BP_FILE_NAME"      VARCHAR2(100),
                        "DIRECTORY_NAME"    VARCHAR2(30),
                        "MIGRATION_STATUS"  VARCHAR2(50) DEFAULT 'TRANSFER NOT STARTED',
                        "START_TIME"        DATE,
                        "ELAPSED_SECONDS"   NUMBER,
                        "BYTES"             NUMBER,
                        "TRANSFERRED_BYTES" NUMBER,
                        CONSTRAINT pk_migration_bp PRIMARY KEY(pdb_name,recid),
                        CONSTRAINT fk_migration_ts FOREIGN KEY(pdb_name,file_id) REFERENCES migration_ts(pdb_name,file_id));        
        CREATE SEQUENCE migration_log_seq START WITH 1 INCREMENT BY 1;
        CREATE TABLE migration_log(
                 id NUMBER DEFAULT migration_log_seq.NEXTVAL,
                 pdb_name VARCHAR2(128),
                 name VARCHAR2(10),
                 log_time DATE DEFAULT SYSDATE,
                 log_message CLOB,
                 CONSTRAINT PK_MIGRATION_LOG PRIMARY KEY(id));
        INSERT INTO migration_log(id, name, log_message) VALUES (migration_log_seq.nextval,'CPW','${CPW}');
        PROMPT "Compiling pck_migration_cdb.sql";
        set echo off;
        @@pck_migration_cdb.sql;
        set echo on;
        show errors;
        BEGIN
            execute immediate 'alter package pck_migration_cdb compile'; 
            exception when others then raise_application_error(-20000,'compilation error');
        END;
        /
EOF
    runsql || { echo "createCommonUser FAILED"; exit 1; }
    
    createCredential "${ORACLE_SID}" "${USER}" "${CPW}" "${ORACLE_SID}" 
}

removeTarget() {
    log "removeTarget"
    
    local FILEPATH=$(runsql -v -s "SELECT MAX(SUBSTR(f.file_name,1,INSTR(f.file_name,'/',-1))) FROM cdb_data_files f, v\$pdbs p WHERE f.con_id=p.con_id AND p.name='${PDB}';");
    chkerr "$?" "${LINENO}" "${FILEPATH}"
    
    [[ -z "${FILEPATH}" ]] && { echo "NO FILEPATH FOR ${PDB}. EXIT IMMEDIATELY."; exit 1; }
    
    cat <<-EOF>${SQLFILE}
        CONNECT ${CONNECT} AS SYSDBA
        WHENEVER SQLERROR CONTINUE
        ALTER PLUGGABLE DATABASE ${PDB} CLOSE IMMEDIATE;
        WHENEVER SQLERROR EXIT FAILURE
        DROP PLUGGABLE DATABASE ${PDB} INCLUDING DATAFILES;
        
        PROMPT FILES REMAINING IN PDB DIRECTORY AFTER SUCCESSFUL DROP
        HOST ls -ltr "${FILEPATH}"
        
        BEGIN
            FOR C IN (SELECT job_name FROM dba_scheduler_jobs WHERE job_name LIKE '%${PDB}') LOOP
                DBMS_SCHEDULER.DROP_JOB(C.job_name);
            END LOOP;
        END;
        /
        
        CONNECT ${CONNECT}
        DROP DATABASE LINK MIGR_DBLINK_${PDB};
        DELETE MIGRATION_BP WHERE PDB_NAME='${PDB}';
        DELETE MIGRATION_TS WHERE PDB_NAME='${PDB}';
        COMMIT;
EOF
    runsql || { echo "removeTarget FAILED"; exit 1; }
    
    deleteCredential "${PDB}"
}


validateTarget() {
    log "validateTarget"
    
    cat <<-EOF>${SQLFILE}
        CONNECT ${CONNECT}
        WHENEVER SQLERROR CONTINUE
        DROP DATABASE LINK MIGR_DBLINK_${PDB};
        WHENEVER SQLERROR EXIT FAILURE
        CREATE DATABASE LINK MIGR_DBLINK_${PDB} CONNECT TO ${DBLINKUSR} IDENTIFIED BY ${DBLINKPWD} USING '${TNS}';
        DECLARE
            l_mismatch VARCHAR2(200):=NULL;
            n PLS_INTEGER;
        BEGIN
            /*
             *  CHECK THAT ALL SOURCE APPLICATION TABLESPACES ARE READ ONLY IF THIS IS A DIRECT MIGRATION 
             */
            SELECT NVL(COUNT(*)-SUM(DECODE(status,'READ ONLY',1,0)),0) INTO n
              FROM V_APP_TABLESPACES@MIGR_DBLINK_${PDB} 
             WHERE NOT EXISTS (SELECT NULL FROM user_scheduler_jobs@MIGR_DBLINK_${PDB});
            IF (n>0) THEN
                RAISE_APPLICATION_ERROR(-20000,'ALL SOURCE APPLICATION TABLESPACES MUST BE READ ONLY BEFORE STARTING MIGRATION.');
            END IF;    

            /*
             *  CHECK SOURCE AND TARGET CHARACTERSETS ARE THE SAME.
             */        
            FOR C IN (
                SELECT COUNT(src) src, COUNT(tgt) tgt, property_name, property_value
                FROM
                (
                SELECT 1 tgt, TO_NUMBER(NULL) src, property_name, property_value 
                FROM database_properties WHERE property_name IN ('NLS_CHARACTERSET','NLS_NCHAR_CHARACTERSET')
                UNION ALL
                SELECT TO_NUMBER(NULL) tgt, 1 src, property_name, property_value 
                FROM database_properties@MIGR_DBLINK_${PDB} WHERE property_name IN ('NLS_CHARACTERSET','NLS_NCHAR_CHARACTERSET')
                )
                GROUP BY property_name, property_value
                ) 
            LOOP
                IF (C.tgt=1 AND C.src=1) THEN
                    CONTINUE;
                END IF;
                IF (C.src=1) THEN
                    l_mismatch:=l_mismatch||' SOURCE '||C.property_name||':'||C.property_value;
                ELSE
                    l_mismatch:=l_mismatch||' TARGET '||C.property_name||':'||C.property_value;
                END IF;
            END LOOP;
            IF (l_mismatch IS NOT NULL) THEN
                RAISE_APPLICATION_ERROR(-20000,'CHARACTER SET MISMATCH. MUST FIRST MIGRATE TO CDB WITH SAME CHARACTERSET AND THEN RELOCATE TO AL32UTF8 CDB - '||l_mismatch);
            END IF;
        END;
        /
EOF
    runsql || { echo "MIGRATION STOPPED. RESOLVE ISSUE AND RETRY."; exit 1; } 
}


createTargetPdb() {
    log "createTargetPdb"
    
    local EXISTS=$(runsql -v -s "SELECT TO_CHAR(COUNT(*)) FROM dual WHERE EXISTS (SELECT 1 FROM dba_users WHERE username='${USER}');")
    chkerr "$?" "${LINENO}" "${EXISTS}"
    
    [[ "${EXISTS}" = "0" ]] && createCommonUser
    
    validateTarget
    
    local PW=$(password)
    
    cat <<-EOF>${SQLFILE}
        CONNECT ${CONNECT} AS SYSDBA
        CREATE PLUGGABLE DATABASE ${PDB} ADMIN USER PDBADMIN IDENTIFIED BY ${PW} ROLES=(DATAPUMP_IMP_FULL_DATABASE) FILE_NAME_CONVERT=('pdbseed','${PDB}');
        ALTER USER ${USER} ADD CONTAINER_DATA = (${PDB}) CONTAINER=CURRENT;
        ALTER SESSION SET CONTAINER=${PDB};
        ALTER PLUGGABLE DATABASE ${PDB} OPEN READ WRITE;
        ALTER PLUGGABLE DATABASE ${PDB} SAVE STATE;
        AUDIT CONNECT;
        ALTER USER PDBADMIN QUOTA UNLIMITED ON SYSTEM;
        GRANT ALTER SESSION,
              ALTER TABLESPACE,
              ANALYZE ANY,
              ANALYZE ANY DICTIONARY,
              CREATE ANY DIRECTORY,
              CREATE JOB,
              CREATE PUBLIC DATABASE LINK,
              CREATE SESSION,
              CREATE TABLESPACE,
              DROP TABLESPACE,
              DROP ANY DIRECTORY,
              SELECT ANY DICTIONARY TO PDBADMIN;
              
        CREATE DIRECTORY MIGRATION_SCRIPT_DIR AS '${CD}';
        GRANT READ, WRITE ON DIRECTORY MIGRATION_SCRIPT_DIR TO PDBADMIN;
        
        COL filepath NEW_VALUE filepath noprint;
        SELECT MAX(SUBSTR(file_name,1,INSTR(file_name,'/',-1)-1)) AS filepath FROM cdb_data_files WHERE con_id=SYS_CONTEXT('USERENV','CON_ID');

        CREATE SEQUENCE PDBADMIN.migration_log_seq START WITH 1 INCREMENT BY 1;
        CREATE TABLE PDBADMIN.migration_log
                       ("ID"            NUMBER DEFAULT PDBADMIN.migration_log_seq.NEXTVAL,
                        "LOG_TIME"      DATE DEFAULT SYSDATE,
                        "LOG_MESSAGE"   CLOB,
                        CONSTRAINT PK_MIGRATION_LOG PRIMARY KEY(id));
        CREATE PUBLIC DATABASE LINK MIGR_DBLINK CONNECT TO ${DBLINKUSR} IDENTIFIED BY ${DBLINKPWD} USING '${TNS}';
        CONNECT ${CONNECT}
        CREATE OR REPLACE DIRECTORY TGT_FILES_DIR_${PDB} AS '&filepath';
EOF
    runsql || { echo "createTargetPdb FAILED"; exit 1; }
    
    createCredential "${PDB}" "PDBADMIN" "${PW}" "${PDB}" 
    
    local CPW=$(runsql -v -s "SELECT log_message FROM ${USER}.migration_log WHERE name='CPW';")
    chkerr "$?" "${LINENO}" "${CPW}"
    
    cat <<-EOF>${SQLFILE}
        CONNECT /@${PDB}
        CREATE DATABASE LINK MIGR_DBLINK_CDB CONNECT TO ${USER} IDENTIFIED BY ${CPW} USING '//localhost/${ORACLE_SID}';
        PROMPT "Compiling pck_migration_pdb.sql";
        set echo off;
        @@pck_migration_pdb.sql;
        set echo on;
        show errors;
        BEGIN
            execute immediate 'alter package pdbadmin.pck_migration_pdb compile'; 
            exception when others then raise_application_error(-20000,'compilation error');
        END;
        /
EOF
    runsql || { echo "createTargetPdb - MIGR_DBLINK_CDB FAILED"; exit 1; }
}


createTargetRunScripts() {
    log "createTargetRunScripts"
    
    local RUNSCRIPT="${1}"
    
    cat <<-EOF>${RUNSCRIPT}.sql
        whenever sqlerror exit failure
        set echo on
        set serveroutput on
        set linesize 300
        variable n number
        connect ${CONNECT}
        begin
            insert into migration_log(pdb_name,name,log_message) VALUES ('${PDB}','STATUS','TRANSFER');
            :n:=pck_migration_cdb.transfer(pPdbname=>'${PDB}');
            dbms_output.put_line('pck_migration_cdb.transfer(${PDB}):'||:n);
        end;
        /
        connect /@${PDB}
        begin
            if (:n=0) then
                insert into migration_log@migr_dblink_cdb(pdb_name,name,log_message) VALUES ('${PDB}','STATUS','DATAPUMP');
                pck_migration_pdb.impdp(pOverride=>${OVERRIDE},pDbmsStats=>${DBMSSTATS});
            end if;
        end;
        /
        exit
EOF

    cat /dev/null>${RUNSCRIPT}.impdp.sh
    
    cat <<-EOF>${RUNSCRIPT}.sh
#!/bin/bash
exec 1>${RUNSCRIPT}.log 2>&1
export ORACLE_HOME=${ORACLE_HOME}
export ORACLE_SID=${ORACLE_SID}
export PATH=\${ORACLE_HOME}/bin:${PATH}
export TNS_ADMIN=${CD}

sqlplus /nolog @${RUNSCRIPT}.sql
[[ \$? = 0 ]] && { echo "TRANSFER COMPLETED"; } || { echo "FAILED TO RUN ${RUNSCRIPT}.sql"; exit 1; }

. ${RUNSCRIPT}.impdp.sh

exit 0
EOF
    chmod u+x ${RUNSCRIPT}.sh    
}


runTargetMigration() {
    log "runTargetMigration"
    
    local RUNSCRIPT="${CD}/${FN}.${PDB}"
    
    createTargetRunScripts "${RUNSCRIPT}"

    cat <<-EOF>${SQLFILE}
        CONNECT ${CONNECT}
        column repeat_interval new_value repeat_interval
        SELECT MAX(repeat_interval) repeat_interval FROM user_scheduler_jobs@migr_dblink_${PDB};
        
        CONNECT ${CONNECT} AS SYSDBA
        BEGIN 
            DBMS_SCHEDULER.CREATE_JOB(
                job_name=>'MIGRATION_${PDB}',
                job_type=>'EXECUTABLE',
                start_date=>SYSTIMESTAMP,
                enabled=>TRUE,
                job_action=>'${RUNSCRIPT}.sh',
                repeat_interval=>'&repeat_interval');
        END;
        /
EOF
    runsql || { echo "runTargetMigration FAILED"; exit 1; }
}


processTarget() {
    log "processTarget"
    
    local EXISTS=$(runsql -v -s "SELECT TO_CHAR(COUNT(*)) FROM dual WHERE EXISTS (SELECT 1 FROM cdb_pdbs WHERE pdb_name='${PDB}');")
    chkerr "$?" "${LINENO}" "${EXISTS}"
    
    [[ "${REMOVE}" = "FALSE"  && (-z "${DBLINKUSR}" || -z "${TNS}" || -z "${PDB}") ]] && { echo "-c <CRED> -t <TNS> -p <PDB> ALL MANDATORY."; exit 1; }
    [[ "${REMOVE}" = "FALSE"  && "${EXISTS}" = "1" ]] && { log "RESTARTING MIGRATION"; runTargetMigration; }
    [[ "${REMOVE}" = "FALSE"  && "${EXISTS}" = "0" ]] && { createTargetPdb; runTargetMigration; }
    
    [[ "${REMOVE}" = "TRUE"  &&  (-n "${DBLINKUSR}" || -n "${TNS}") ]] && { echo "-p <PDB> -r   MUST BE THE ONLY PARAMETERS SPECIFIED TO REMOVE PDB"; exit 1; }
    [[ "${REMOVE}" = "TRUE"  &&  "${EXISTS}" = "0" ]] && { echo "PDB DOES NOT EXIST."; exit 1; }
    [[ "${REMOVE}" = "TRUE" ]] && { removeTarget; }
}


##########################
#   SCRIPT STARTS HERE   #
##########################

SCRIPT=$(basename $0); FN="${SCRIPT%.*}"; SQLFILE=${FN}.sql; CD=$(pwd)

unset BKPDIR
unset DBLINKUSR
unset BKPFREQ
unset MODE
unset PDB
unset TNS
unset USER
unset REMOVE
unset DBMSSTATS
unset OVERRIDE

while getopts "::b:c:f:m:o:p:t:rh12z" o; do
    case "${o}" in
        b) BKPDIR=${OPTARG} ;;
        c) DBLINKUSR=${OPTARG%%/*}; DBLINKPWD=${OPTARG#*/} ;;
        f) BKPFREQ=${OPTARG} ;;
        m) MODE=$(upper ${OPTARG}) ;;
        o) ORACLE_SID=$(upper ${OPTARG}); ORAENV_ASK=NO; . oraenv ;;
        p) PDB=$(upper ${OPTARG}) ;;
        t) TNS=${OPTARG} ;;
        u) USER=${OPTARG} ;;
        r) REMOVE=TRUE ;;
        1) DBMSSTATS=FALSE ;;
        2) OVERRIDE=TRUE ;;
        z) zip autoMigrate.zip  runMigration.sh pck_migration_src.sql pck_migration_cdb.sql pck_migration_pdb.sql ;;
        h) usageTarget ;;
        :) echo "ERROR -${OPTARG} REQUIRES  ARGUMENT"; usageTarget ;;
        *) usageTarget ;;
    esac
done

LOGFILE=${FN}.${ORACLE_SID}.log

exec > >(tee ${LOGFILE}) 2>&1

# Confirm ORACLE_SID is running
#
DBUP=$(ps -ef | grep -v grep | grep pmon_${ORACLE_SID} | wc -l)
[[ "${DBUP}" = "0" ]] && { echo "${ORACLE_SID} NOT RUNNING ON THIS SERVER"; exit 1; }

# Create network config files in current directory if not exists
#
export TNS_ADMIN="${CD}"
TNSNAMES="${TNS_ADMIN}/tnsnames.ora"; [[ -f "${TNSNAMES}" ]] || cat /dev/null>"${TNSNAMES}"
SQLNET="${TNS_ADMIN}/sqlnet.ora"; [[ -f "${SQLNET}" ]] || cat /dev/null>"${SQLNET}"
WALLET="${TNS_ADMIN}/wallet"

# Set default sqlplus CONNECT string if credential for ORACLE_SID exists
#
CRED=$(grep "^${ORACLE_SID}" "${TNSNAMES}"|wc -l)
[[ "${CRED}" = "1" ]] && CONNECT="/@${ORACLE_SID}" || CONNECT="/ AS SYSDBA"

# DB version determines whether we process as SOURCE or TARGET
#
VERSION=$(runsql -v -s "SELECT MAX(REGEXP_SUBSTR(banner,'\d+.\d+.\d+.\d+')) FROM v\$version;")
chkerr "$?" "${LINENO}" "${VERSION}"

# If we are version 19 database then process for TARGET else SOURCE
#
[[ ${VERSION} = 19* ]] && DB=TARGET || DB=SOURCE


case "${DB}" in
    SOURCE)
        [[ -z "${USER}" ]] && USER=MIGRATION19
        [[ -z "${MODE}" ]] && MODE=ANALYZE
        [[ -z "${REMOVE}" ]] && REMOVE=FALSE
        processSource
        ;;
    TARGET)
        [[ -z "${USER}" ]] && USER=C##MIGRATION
        [[ -z "${DBMSSTATS}" ]] && DBMSSTATS=TRUE
        [[ -z "${OVERRIDE}" ]] && OVERRIDE=FALSE
        [[ -z "${REMOVE}" ]] && REMOVE=FALSE
        processTarget
        ;;
esac

exit 0