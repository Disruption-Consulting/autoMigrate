#!/bin/bash

SCRIPT=$(basename $0); FN="${SCRIPT%.*}"; LOGFILE=${FN}.log; SQLFILE=${FN}.sql; CD=$(pwd)

exec > >(tee ${LOGFILE}) 2>&1

export TNS_ADMIN="${CD}"

USER=MIGRATION19

rm -i -r "${TNS_ADMIN}/wallet" "${TNS_ADMIN}/tnsnames.ora" "${TNS_ADMIN}/sqlnet.ora"

sqlplus /nolog<<EOF
    CONNECT / AS SYSDBA
    WHENEVER SQLERROR CONTINUE
    SET SERVEROUTPUT ON
    PROMPT "DROP USER ${USER} CASCADE;"
    DROP USER ${USER} CASCADE;
    DECLARE
        PROCEDURE exec(pCommand IN VARCHAR2) IS
        BEGIN
            dbms_output.put('About to '||pCommand);
            EXECUTE IMMEDIATE pCommand;
            dbms_output.put_line(' ... OK');
            EXCEPTION WHEN OTHERS THEN
                dbms_output.put_line(' ... FAILED'); RAISE;
        END;
    BEGIN
        FOR C IN (SELECT directory_name FROM dba_directories WHERE directory_name LIKE '${USER}_%_DIR') LOOP
                exec('DROP DIRECTORY '||C.directory_name);
        END LOOP;
    END;
    /
    EXIT
EOF

exit