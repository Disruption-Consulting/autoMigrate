CREATE OR REPLACE PACKAGE pck_migration_noncdb AS
    --
    PROCEDURE set_ts_readwrite;
    --
    PROCEDURE set_ts_readonly;
    --
    PROCEDURE uploadLog(pFilename IN VARCHAR2);
    --
    PROCEDURE log_details;
    --
    PROCEDURE export_stats;
END;
/

CREATE OR REPLACE PACKAGE BODY pck_migration_noncdb AS
/*
    NAME
      pck_migration_noncdb

    DESCRIPTION
      This package is called by "runMigration.sh" to prepare this NONCDB database for migration to PDB via DBLINK.
*/

    TTS_CHECK_FAILED EXCEPTION; 
    
    MIGRSCHEMA VARCHAR2(20):=SYS_CONTEXT('USERENV','CURRENT_SCHEMA');

    -------------------------------
    PROCEDURE log(pLine IN VARCHAR2, pChar IN VARCHAR2 DEFAULT NULL) IS
        l_pos PLS_INTEGER:=INSTR(pLine,':');
    BEGIN
        IF (pChar IS NULL) THEN
            dbms_output.put_line(RPAD(SUBSTR(pLine,1,l_pos-1),30) || SUBSTR(pLine,l_pos));
        ELSE
            dbms_output.put_line(RPAD(pChar,30,pChar));
            dbms_output.put_line(pLine);
            dbms_output.put_line(RPAD(pChar,30,pChar));
        END IF;
    END;

    -------------------------------
    PROCEDURE exec(pCommand IN VARCHAR2) IS
        l_log LONG;
    BEGIN
        l_log:='About to ... '||pCommand;
        EXECUTE IMMEDIATE pCommand;
        log(l_log||' ...OK');
        EXCEPTION
            WHEN OTHERS THEN
                log(l_log||' ...FAILED');
                RAISE;
    END;

    -------------------------------
    PROCEDURE fileToClob(pDirName IN VARCHAR2, pFilename IN VARCHAR2, pClob IN OUT NOCOPY CLOB) IS
        l_bfile   BFILE;
        d_offset  NUMBER := 1;
        s_offset  NUMBER := 1;
        l_csid    NUMBER := 0;
        l_lang    NUMBER := 0;
        l_warning NUMBER;
    BEGIN
        l_bfile:=bfilename(pDirName,pFilename);
        dbms_lob.fileopen(l_bfile, dbms_lob.file_readonly);
        dbms_lob.loadclobfromfile(pClob, l_bfile, DBMS_LOB.lobmaxsize, d_offset,s_offset,l_csid, l_lang, l_warning);
        dbms_lob.fileclose(l_bfile);
    END;

    --
    -- PROCEDURE uploadLog
    --   Inserts OS file as log message row in table migration_log.
    --   Delete OS file to avoid exposing passwords at OS level
    --
    -------------------------------
    PROCEDURE uploadLog(pFilename IN VARCHAR2) IS
        l_clob    CLOB;
    BEGIN
        INSERT INTO migration_log (id, log_message) VALUES (migration_log_seq.nextval, empty_clob()) RETURN log_message INTO l_clob;
        fileToClob(MIGRSCHEMA||'_SCRIPT_DIR',pFilename,l_clob);
        COMMIT;
        utl_file.fremove(location=>MIGRSCHEMA||'_SCRIPT_DIR', filename=>pFilename);
    END;
    
    
    -------------------------------
    PROCEDURE reset_password(p_password IN VARCHAR2) IS
    BEGIN
        EXECUTE IMMEDIATE 'ALTER USER '||MIGRSCHEMA||' IDENTIFIED BY '||p_password;
    END;

    -------------------------------
    PROCEDURE log_details IS
        l_apex varchar2(100);
        l_clob clob;
        l_oracle_sid varchar2(30);
        l_oracle_home varchar2(100);
        l_files SYS.ODCIVARCHAR2LIST:=SYS.ODCIVARCHAR2LIST('tnsnames.ora','sqlnet.ora','listener.ora');
        l_dblinks SYS.ODCIVARCHAR2LIST:=SYS.ODCIVARCHAR2LIST();
        l_dbtimezone VARCHAR2(50);
        n PLS_INTEGER:=0;
        FILENOTEXISTS EXCEPTION;
        PRAGMA exception_init (FILENOTEXISTS, -22288);
    BEGIN
        sys.dbms_system.get_env('ORACLE_SID',l_oracle_sid);
        sys.dbms_system.get_env('ORACLE_HOME',l_oracle_home);
        
        l_apex:='APEX NOT INSTALLED OR NOT USED';
        FOR C IN (SELECT version FROM dba_registry WHERE comp_id='APEX') LOOP
            EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM dual WHERE EXISTS (SELECT NULL FROM apex_applications WHERE workspace<>''INTERNAL'')' INTO n;
            IF (n>0) THEN
                l_apex:='APEX APPLICATIONS MUST BE EXPORTED/IMPORTED INTO TARGET PDB, WHICH NEEDS MINIMUM APEX INSTALLATION VERSION 18.2';
            END IF;
        END LOOP;        
        
        DELETE properties;
        INSERT INTO properties(name, value, description)
        SELECT 'VERSION',MAX(REGEXP_SUBSTR(banner,'\d+.\d+.\d+.\d+')),'v$version.banner' FROM v$version
        UNION ALL
        SELECT UPPER(name),RTRIM(value),'v$parameter.value' FROM v$parameter WHERE name IN ('compatible','pga_aggregate_target','processes','sga_max_size','sga_target')
        UNION ALL
        SELECT property_name, property_value, description FROM database_properties
        UNION ALL
        SELECT stat_name, TO_CHAR(value), comments FROM V$osstat
        UNION ALL
        SELECT 'HOST_NAME',host_name,'v$instance.host_name' FROM v$instance
        UNION ALL
        SELECT 'LOG_MODE',log_mode,'v$database.log_mode' FROM v$database
        UNION ALL 
        SELECT 'BCT_STATUS',status,'v$block_change_tracking.status' FROM v$block_change_tracking
        UNION ALL
        SELECT 'APEX_STATUS',l_apex,'APEX installation and usage' FROM dual
        UNION ALL
        SELECT 'ORACLE_SID',l_oracle_sid,'Environment variable' FROM dual
        UNION ALL
        SELECT 'ORACLE_HOME',l_oracle_home,'Environment variable' FROM dual
        UNION ALL
        SELECT 'APP_TABLESPACES_'||status||'_GB', TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024,2)), 'Size of application tablesapces with status - '||status FROM v_app_tablespaces GROUP BY status
        ;

        dbms_lob.createtemporary(lob_loc => l_clob, cache => true, dur => dbms_lob.call);
        FOR i IN 1..l_files.COUNT LOOP
            BEGIN
                fileToClob('TNS_ADMIN',l_files(i),l_clob);
                INSERT INTO properties(name, contents, description) VALUES (l_files(i),l_clob,'Contents of '||l_files(i));       
                EXCEPTION WHEN FILENOTEXISTS THEN NULL; WHEN OTHERS THEN RAISE;
            END;
        END LOOP;
        dbms_lob.freetemporary(lob_loc => l_clob);  

        log('NONCDB TO PDB MIGRATION','-');
        log('ORACLE_SID : '||l_oracle_sid);
        log('ORACLE_HOME : '||l_oracle_home);

        /*
         *  DATABASE LINK ANALYSIS
         */
        SELECT COUNT(*) INTO n FROM dba_db_links WHERE owner<>'SYS';

        IF (n=0) THEN
            log('DB LINK ANALYSIS : THERE ARE NO DB LINKS IN THIS DATABASE');
        ELSE
            log('DB LINK ANALYSIS : THERE ARE '||n||' DB LINKS IN THIS DATABASE:');
        END IF;

        SELECT dbtimezone INTO l_dbtimezone FROM dual;
        
        FOR C IN (SELECT owner || CASE WHEN owner='PUBLIC' THEN '_' ELSE '.' END ||'DBLINK' job_name, owner, db_link, host
            FROM dba_db_links
           WHERE owner<>'SYS'
           ORDER BY owner, db_link)
        LOOP
            DBMS_SCHEDULER.create_job (
                job_name     => C.job_name,
                job_type     => 'PLSQL_BLOCK',
                start_date   => TO_TIMESTAMP_TZ(TO_CHAR(SYSTIMESTAMP, 'DDMMYYYY HH24:MI:SS')||' '||l_dbtimezone, 'DDMMYYYY HH24:MI:SS TZR'),
                job_action   => REPLACE('DECLARE x VARCHAR2(1); BEGIN SELECT dummy INTO x FROM dual@#DBLINK#; END;','#DBLINK#',C.db_link)
            );
           BEGIN
               l_dblinks.EXTEND;
               l_dblinks(l_dblinks.COUNT):='OWNER:'||C.owner||'; DBLINK:'||C.db_link||'; HOST:'||C.host||';';
                DBMS_SCHEDULER.run_job (C.job_name, TRUE);
                l_dblinks(l_dblinks.COUNT):=l_dblinks(l_dblinks.COUNT)||'=> OK';
           EXCEPTION
               WHEN OTHERS THEN l_dblinks(l_dblinks.COUNT):=l_dblinks(l_dblinks.COUNT)||'=> NOK - '||SUBSTR(SQLERRM,1,INSTR(SQLERRM,CHR(10))-1);
           END;
           DBMS_SCHEDULER.drop_job (C.job_name);
        END LOOP;
         
        FOR i IN 1..l_dblinks.COUNT LOOP
            INSERT INTO properties(name, value, description) VALUES ('APPLICATION_DBLINK', l_dblinks(i), 'DBLINK analysis');
        END LOOP;
        
        FOR C IN (
            SELECT REGEXP_SUBSTR(l.value,'HOST=(\w+)',1,1,'i',1)||':'||REGEXP_SUBSTR(l.value,'PORT=(\d+)',1,1,'i',1)||'/'||s.value ezconnect
              FROM v$listener_network l, v$listener_network s, global_name
             WHERE l.type='LOCAL LISTENER' AND s.type='SERVICE NAME' AND UPPER(s.value)=global_name)
        LOOP
            log('RUN MIGRATION ON CDB : ./runMigration.sh -n '||C.ezconnect);
        END LOOP;
    END;


    -------------------------------
    PROCEDURE check_tts_set IS
    /*
     *  CHECK TABLESPACES TO BE TRANSPORTED ARE SELF-CONTAINED - I.E NO APPLICATION SEGMENTS IN SYSTEM OR SYSAUX
     */
        n PLS_INTEGER:=0;
    BEGIN
        FOR C IN (SELECT s.owner, s.segment_type, s.segment_name, s.tablespace_name
                    FROM dba_segments s, dba_users u
                   WHERE s.owner=u.username
                     AND u.oracle_maintained='N'
                     AND u.username<>MIGRSCHEMA
                     AND s.tablespace_name in ('SYSTEM','SYSAUX')
                   ORDER BY s.segment_type, s.owner)
        LOOP
            n:=n+1;
            IF (n=1) THEN
                log('TTS CHECK VIOLATIONS DETECTED - MOVE FOLLOWING INTO APPLICATION TABLESPACES','*');
            END IF;
            log(C.segment_type || ' ' ||C.owner || '.' || C.segment_name || ' IN TABLESPACE ' || C.tablespace_name );
        END LOOP;

        IF (n>0) THEN
            RAISE TTS_CHECK_FAILED;
        END IF;
    END;
    
    
    -------------------------------
    PROCEDURE export_stats IS
    BEGIN
        FOR C IN (SELECT username FROM dba_users WHERE oracle_maintained='N') LOOP
            dbms_stats.export_schema_stats(ownname=>C.username, stattab=>'DBMS_STATS_TABLE', statown=>MIGRSCHEMA);
        END LOOP;
    END;
    
    
    -------------------------------
    PROCEDURE incremental_bacup IS
    BEGIN
        FOR C IN (SELECT username FROM dba_users WHERE oracle_maintained='N') LOOP
            dbms_stats.export_schema_stats(ownname=>C.username, stattab=>'DBMS_STATS_TABLE', statown=>MIGRSCHEMA);
        END LOOP;
    END;
    
    
    -------------------------------
    PROCEDURE set_ts_readwrite IS
    /*
     *  SET TABLESPACES BACK TO THEIR ORIGINAL STATUS. TYPICALLY DO THS AFTER MIGRATION.
     */
    BEGIN
        FOR C IN (WITH post_migration_ts AS (SELECT DISTINCT tablespace_name, status FROM v_app_tablespaces)
                  SELECT t2.tablespace_name
                    FROM pre_migration_ts t1, post_migration_ts t2
                   WHERE t1.tablespace_name=t2.tablespace_name
                     AND t1.status<>t2.status
                     AND t2.status='READ ONLY')
        LOOP
            exec('ALTER TABLESPACE '||C.tablespace_name||' READ WRITE');
        END LOOP;
    END;

    -------------------------------
    PROCEDURE set_ts_readonly IS
    /*
     *  SET APPLICATION TABLESPACES TO READ ONLY. PRESERVE PRE_MIGRATION STATUS TO BE APPLIED POST MIGRATION.
     */
    BEGIN
        check_tts_set;
        
        DELETE pre_migration_ts;
        INSERT INTO pre_migration_ts(tablespace_name, status)
        SELECT DISTINCT tablespace_name, status FROM v_app_tablespaces;
        COMMIT;
        
        FOR C IN (SELECT DISTINCT ts_name, owner FROM dba_recyclebin WHERE ts_name IS NOT NULL AND ts_name NOT IN ('SYSTEM','SYSAUX')) LOOP
            exec('PURGE TABLESPACE '||C.ts_name||' USER '||C.owner);
        END LOOP;

        FOR C IN (SELECT tablespace_name FROM pre_migration_ts WHERE status='ONLINE')
        LOOP
            exec('ALTER TABLESPACE ' || C.tablespace_name || ' READ ONLY');
        END LOOP;
    END;

    
    -------------------------------
    PROCEDURE create_transfer_directories IS
    /*
     *  CREATE DIRECTORIES FOR REFERENCE BY DBMS_FILE_TRANSFER ON TARGET
     */
    BEGIN
        FOR C IN (SELECT directory_name, ROWNUM rn FROM 
                    ( SELECT DISTINCT SUBSTR(f.file_name,1,INSTR(f.file_name,'/',-1)-1) directory_name
                        FROM dba_tablespaces t, dba_data_files f
                       WHERE t.tablespace_name=f.tablespace_name
                         AND t.contents='PERMANENT'
                         AND t.tablespace_name NOT IN ('SYSTEM','SYSAUX')
                    )
        ) LOOP
            exec('CREATE OR REPLACE DIRECTORY '|| MIGRSCHEMA ||'_FILES_'||C.rn||'_DIR AS '''||C.directory_name||'''');
        END LOOP;
    END;
    
END;
/