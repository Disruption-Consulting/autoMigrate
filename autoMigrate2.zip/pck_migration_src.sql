CREATE OR REPLACE PACKAGE pck_migration_src AS
    --
    PROCEDURE set_ts_readwrite;
    --
    PROCEDURE set_ts_readonly;
    --
    PROCEDURE uploadLog(pFilename IN VARCHAR2);
    --
    FUNCTION getDefaultServiceName RETURN VARCHAR2;
    --
    PROCEDURE reset_password(p_password IN VARCHAR2);
END;
/

CREATE OR REPLACE PACKAGE BODY pck_migration_src AS
/*
    NAME
      pck_migration_src

    DESCRIPTION
      This package is called from "runMigration.sh" to prepare the database for migration either directly or by a process of continuous recovery.

      Full details available at https://github.com/xsf3190/automigrate.git
*/

    TTS_CHECK_FAILED EXCEPTION; 
    
    MIGRSCHEMA VARCHAR2(20):=SYS_CONTEXT('USERENV','CURRENT_SCHEMA');

    -------------------------------
    PROCEDURE log(pLine IN VARCHAR2, pChar IN VARCHAR2 DEFAULT NULL) IS
        l_now VARCHAR2(25):=TO_CHAR(SYSDATE,'MM.DD.YYYY HH24:MI:SS')||' - ';
    BEGIN
        IF (pChar IS NULL) THEN
            dbms_output.put_line(l_now||pLine);
        ELSE
            dbms_output.put_line(l_now||RPAD(pChar,LENGTH(pLine),pChar));
            dbms_output.put_line(l_now||pLine);
            dbms_output.put_line(l_now||RPAD(pChar,LENGTH(pLine),pChar));
        END IF;
    END;

    -------------------------------
    PROCEDURE exec(pCommand IN VARCHAR2) IS
        l_log LONG;
    BEGIN
        l_log:='About to ... '||pCommand;
        EXECUTE IMMEDIATE pCommand;
        log(l_log||' ...OK');
        EXCEPTION
            WHEN OTHERS THEN
                log(l_log||' ...FAILED');
                RAISE;
    END;

    -------------------------------
    PROCEDURE fileToClob(pFilename IN VARCHAR2, pClob IN OUT NOCOPY CLOB) IS
        l_bfile   BFILE;
        d_offset  NUMBER := 1;
        s_offset  NUMBER := 1;
        l_csid    NUMBER := 0;
        l_lang    NUMBER := 0;
        l_warning NUMBER;
    BEGIN
        l_bfile:=bfilename(MIGRSCHEMA||'_SCRIPT_DIR',pFilename);
        dbms_lob.fileopen(l_bfile, dbms_lob.file_readonly);
        dbms_lob.loadclobfromfile(pClob, l_bfile, DBMS_LOB.lobmaxsize, d_offset,s_offset,l_csid, l_lang, l_warning);
        dbms_lob.fileclose(l_bfile);
    END;

    --
    -- PROCEDURE uploadLog
    --   Inserts OS file as log message row in table migration_log.
    --   Delete OS file to avoid exposing passwords at OS level
    --
    -------------------------------
    PROCEDURE uploadLog(pFilename IN VARCHAR2) IS
        l_clob    CLOB;
    BEGIN
        INSERT INTO migration_log (id, log_message) VALUES (migration_log_seq.nextval, empty_clob()) RETURN log_message INTO l_clob;
        fileToClob(pFilename,l_clob);
        COMMIT;
        utl_file.fremove(location=>MIGRSCHEMA||'_SCRIPT_DIR', filename=>pFilename);
    END;

    -------------------------------
    FUNCTION version(pVersion IN VARCHAR2) RETURN NUMBER IS
        l_version_2 VARCHAR2(20):=pVersion;
        l_version_n NUMBER;
        l_dots INTEGER:=LENGTH(pVersion)-LENGTH( REPLACE( pVersion, '.' ));
    BEGIN
        /*
         *  Convert Oracle version string into a number.  Nb. first, convert for example "12.1" to "12.1.0.0.0" to ensure correct calculation
         */
        FOR i IN l_dots..3 LOOP
            l_version_2:=l_version_2||'.0';
        END LOOP;
        SELECT SUM(v*POWER(10,n))
        INTO l_version_n
        FROM
            (
            SELECT REGEXP_SUBSTR(l_version_2,'[^.]+', 1, level) v, ROW_NUMBER() OVER (ORDER BY LEVEL DESC) n
              FROM dual
            CONNECT BY REGEXP_SUBSTR(l_version_2, '[^.]+', 1, level) IS NOT NULL
            );
        RETURN(l_version_n);
    END;

    -------------------------------
    FUNCTION getDefaultServiceName RETURN VARCHAR2 IS
        l_service_name v$services.name%type;
    BEGIN
        l_service_name:='**TO_BE_PROVIDED**';
        FOR C IN (
                    WITH dflt AS
                    (
                    SELECT p1.value||NVL2(p2.value,'.'||p2.value,null) service_name
                    FROM v$parameter p1, v$parameter p2
                    WHERE p1.name='db_name'
                    AND p2.name='db_domain'
                    )
                    SELECT s.name
                    FROM v$services s, dflt d
                    WHERE s.name=d.service_name
                )
        LOOP
            l_service_name:=C.name;
        END LOOP;
        RETURN (l_service_name);
    END;
    
    -------------------------------
    PROCEDURE reset_password(p_password IN VARCHAR2) IS
    BEGIN
        EXECUTE IMMEDIATE 'ALTER USER '||MIGRSCHEMA||' IDENTIFIED BY '||p_password;
    END;

    -------------------------------
    PROCEDURE log_details(pRunMode IN VARCHAR2, pVersion IN VARCHAR2, pCompatibility IN VARCHAR2, p_bkpdir IN VARCHAR2) IS
        l_apex varchar2(100);
        l_bct_status v$block_change_tracking.status%type;
        l_characterset varchar2(20);
        l_clob clob;
        l_db_name v$database.name%type;
        l_hash_runmigration varchar2(40);
        l_hash_pck_migration_src varchar2(40);
        l_host_name v$instance.host_name%type;
        l_ip_address varchar2(20);
        l_log_mode v$database.log_mode%type;
        l_migration_method VARCHAR2(21);
        l_migration_explained VARCHAR2(200);
        l_oracle_sid varchar2(30);
        l_oracle_pdb_sid varchar2(30);
        l_oracle_home varchar2(100);
        l_platform v$database.platform_name%type;
        l_rman_incr_xtts VARCHAR2(100);
        l_running_execute BOOLEAN;
        l_running_incr_ts BOOLEAN;
        l_service_name v$services.name%type;
        l_this_version NUMBER:=version(pVersion);
        l_tns_admin varchar2(100);
        l_total_bytes number:=0;
        l_ts_list_rw LONG:=NULL;
        l_ts_list_ro LONG:=NULL;
        l_job_action LONG;
        n PLS_INTEGER:=0;
    BEGIN
        dbms_lob.createtemporary(lob_loc => l_clob, cache => true, dur => dbms_lob.call);
        fileToClob('runMigration.sh',l_clob);
        l_hash_runmigration:=dbms_crypto.hash(l_clob,dbms_crypto.hash_sh1);
        dbms_lob.freetemporary(lob_loc => l_clob);

        dbms_lob.createtemporary(lob_loc => l_clob, cache => true, dur => dbms_lob.call);
        fileToClob('pck_migration_src.sql',l_clob);
        l_hash_pck_migration_src:=dbms_crypto.hash(l_clob,dbms_crypto.hash_sh1);
        dbms_lob.freetemporary(lob_loc => l_clob);

        sys.dbms_system.get_env('ORACLE_PDB_SID',l_oracle_pdb_sid);
        sys.dbms_system.get_env('ORACLE_SID',l_oracle_sid);
        sys.dbms_system.get_env('ORACLE_HOME',l_oracle_home);
        sys.dbms_system.get_env('TNS_ADMIN',l_tns_admin);

        IF (l_tns_admin IS NULL) THEN
            l_tns_admin:=l_oracle_home||'/network/admin (DEFAULT)';
        END IF;

        SELECT d.name, i.host_name, d.log_mode, d.platform_name, p1.property_value
          INTO l_db_name, l_host_name, l_log_mode, l_platform, l_characterset
          FROM v$database d, v$instance i, database_properties p1, v$transportable_platform tp
         WHERE p1.property_name='NLS_CHARACTERSET'
           AND tp.platform_name=d.platform_name;

        l_bct_status:='DISABLED';
        FOR C IN (SELECT status FROM v$block_change_tracking) LOOP
            l_bct_status:=C.status;
        END LOOP;

        /*
         *  FULL TRANSPORTABLE DATABASE MIGRATION REQUIRES THAT SOURCE IS >= 11.2.0.3 ELSE WE DO TRANSPORTABLE TABLESPACE MIGRATION
         *  MINIMUM SOURCE REQUIREMENT FOR XTTS IS VERSION: 10.1.0.3  COMPATIBILITY: 10.0
         */
        IF (l_this_version >= version('11.2.0.3')) THEN
            l_migration_method:='XTTS_DB';
            l_migration_explained:='VERSION >= 11.2.0.3  => OPTIMAL MIGRATION IS FULL TRANSPORTABLE DATABASE';
        ELSIF (l_this_version >= version('10.1.0.3') AND version(pCompatibility)>=version('10')) THEN
            l_migration_method:='XTTS_TS';
            l_migration_explained:='VERSION >= 10.1.0.3 AND < 11.2.0.3  => OPTIMAL MIGRATION IS TRANSPORTABLE TABLESPACE';
        END IF;

        FOR C IN (SELECT DISTINCT status, tablespace_name, SUM(bytes) OVER() total_bytes FROM v_app_tablespaces) LOOP
            IF (C.status='ONLINE') THEN
                l_ts_list_rw:=l_ts_list_rw||C.tablespace_name||',';
            ELSIF (C.status='READ ONLY') THEN
                l_ts_list_ro:=l_ts_list_ro||C.tablespace_name||',';
            END IF;
            l_total_bytes:=C.total_bytes;
        END LOOP;

        IF (l_log_mode='ARCHIVELOG' AND l_bct_status<>'DISABLED') THEN
            l_rman_incr_xtts:='OK';
            IF (p_bkpdir IS NOT NULL) THEN
                l_rman_incr_xtts:=l_rman_incr_xtts||' - PROCESS RUNNING';
            END IF;
        ELSE
            l_rman_incr_xtts:='NOK - DATABASE MUST BE ARCHIVELOG AND BLOCK CHANGE TRACKING ENABLED';
        END IF;

        /*
         *  SIGNAL WARNING IF NO DEFAULT LISTENING SERVICE
         */
        l_service_name:=getDefaultServiceName();

        /*
         *  SIGNAL IF APEX INSTALLED BUT NOT USED
         */
        l_apex:='APEX NOT INSTALLED OR NOT USED';
        FOR C IN (SELECT version FROM dba_registry WHERE comp_id='APEX') LOOP
            EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM dual WHERE EXISTS (SELECT NULL FROM apex_applications WHERE workspace<>''INTERNAL'')' INTO n;
            IF (n>0) THEN
                l_apex:='APEX APPLICATIONS MUST BE EXPORTED/IMPORTED INTO TARGET PDB, WHICH NEEDS MINIMUM APEX INSTALLATION VERSION 18.2';
            END IF;
        END LOOP;
        
        SELECT log_message INTO l_ip_address FROM migration_log WHERE name='IP';

        log('             DATABASE MIGRATION','-');
        log('             RUN MODE : '||pRunMode);
        log('           ORACLE_SID : '||l_oracle_sid);
        log('      runMigration.sh : '||l_hash_runmigration||' (SHA-1)');
        log('pck_migration_src.sql : '||l_hash_pck_migration_src||' (SHA-1)');
        log('       ORACLE_PDB_SID : '||NVL(l_oracle_pdb_sid,'N/A'));
        log('          ORACLE_HOME : '||l_oracle_home);
        log('            TNS_ADMIN : '||l_tns_admin);
        log('             DATABASE : '||l_db_name);
        log('             LOG MODE : '||l_log_mode);
        log('              VERSION : '||pVersion);
        log('        COMPATIBILITY : '||pCompatibility);
        log('        CHARACTER SET : '||l_characterset);
        log('                 APEX : '||l_apex);
        log('             HOSTNAME : '||l_host_name);
        log(' DBLINK FOR MIGRATION : '||'USER='||MIGRSCHEMA
                                      ||' HOST='||l_ip_address
                                      ||' SERVICE='||COALESCE(l_oracle_pdb_sid,l_service_name));
        log('        PLATFORM NAME : '||l_platform);
        log('        DATABASE SIZE : '||LTRIM(TO_CHAR(ROUND(l_total_bytes/1024/1024/1024,2),'999,999,990.00')|| ' GB'));
        log('BLOCK CHANGE TRACKING : '||l_bct_status);
        log('      TABLESPACES R/W : '||NVL(RTRIM(l_ts_list_rw,','),'-NONE-'));
        log('      TABLESPACES R/O : '||NVL(RTRIM(l_ts_list_ro,','),'-NONE-'));
        log('   INCREMENTAL BACKUP : '||l_rman_incr_xtts);
        log('     MIGRATION METHOD : '||l_migration_method);
        log('   METHOD EXPLANATION : '||l_migration_explained);

        /*
         *  DATABASE LINK ANALYSIS
         */
        SELECT COUNT(*) INTO n FROM dba_db_links WHERE owner<>'SYS';

        IF (n=0) THEN
            log('     DB LINK ANALYSIS : THERE ARE NO DB LINKS IN THIS DATABASE');
        ELSE
            log('     DB LINK ANALYSIS : THERE ARE '||n||' DB LINKS IN THIS DATABASE:');
        END IF;

        l_job_action:=q'{
        BEGIN
          FOR C IN (SELECT global_name, '#DBLINK#' db_link, '#OWNER#' owner, '#HOST#' host FROM global_name@#DBLINK#) LOOP
            DBMS_OUTPUT.put_line(TO_CHAR(SYSDATE,'MM.DD.YYYY HH24:MI:SS')||' -                       : GLOBAL_NAME:'||C.global_name||'; OWNER:'||C.owner||'; DBLINK:'||C.db_link||'; HOST:'||C.host||'; => OK');
          END LOOP;
        END;}';
        FOR C IN (SELECT owner || CASE WHEN owner='PUBLIC' THEN '_' ELSE '.' END ||'DBLINK' job_name, owner, db_link, host
            FROM dba_db_links
           WHERE owner<>'SYS'
           ORDER BY owner, db_link)
        LOOP
            DBMS_SCHEDULER.create_job (
                job_name     => C.job_name,
                job_type     => 'PLSQL_BLOCK',
                job_action   => REPLACE(REPLACE(REPLACE(l_job_action,'#DBLINK#',C.db_link),'#HOST#',C.host),'#OWNER#',C.owner)
            );

           BEGIN
               DBMS_SCHEDULER.run_job (C.job_name, TRUE);
           EXCEPTION
               WHEN OTHERS
               THEN
                   DBMS_OUTPUT.put_line(TO_CHAR(SYSDATE,'MM.DD.YYYY HH24:MI:SS')||' -                       : OWNER:'||C.owner||'; DBLINK:'||C.db_link||'; HOST:'||C.host||'; => NOK - '||SUBSTR(SQLERRM,1,INSTR(SQLERRM,CHR(10))-1));
           END;
           DBMS_SCHEDULER.drop_job (C.job_name);
        END LOOP;
    END;

    -------------------------------
    PROCEDURE check_tts_set IS
    /*
     *  CHECK TABLESPACES TO BE TRANSPORTED ARE SELF-CONTAINED - I.E NO APPLICATION SEGMENTS IN SYSTEM OR SYSAUX
     */
        n PLS_INTEGER:=0;
    BEGIN
        FOR C IN (SELECT s.owner, s.segment_type, s.segment_name, s.tablespace_name
                    FROM dba_segments s, dba_users u
                   WHERE s.owner=u.username
                     AND u.oracle_maintained='N'
                     AND u.username<>MIGRSCHEMA
                     AND s.tablespace_name in ('SYSTEM','SYSAUX')
                   ORDER BY s.segment_type, s.owner)
        LOOP
            n:=n+1;
            IF (n=1) THEN
                log('TTS CHECK VIOLATIONS DETECTED - MOVE FOLLOWING INTO APPLICATION TABLESPACES','*');
            END IF;
            log(C.segment_type || ' ' ||C.owner || '.' || C.segment_name || ' IN TABLESPACE ' || C.tablespace_name );
        END LOOP;

        IF (n>0) THEN
            RAISE TTS_CHECK_FAILED;
        END IF;
    END;

    -------------------------------
    PROCEDURE set_ts_readwrite IS
    /*
     *  SET TABLESPACES BACK TO THEIR ORIGINAL STATUS. TYPICALLY DO THS AFTER MIGRATION.
     */
    BEGIN
        FOR C IN (WITH post_migration_ts AS (SELECT DISTINCT tablespace_name, status FROM v_app_tablespaces)
                  SELECT t2.tablespace_name
                    FROM pre_migration_ts t1, post_migration_ts t2
                   WHERE t1.tablespace_name=t2.tablespace_name
                     AND t1.status<>t2.status
                     AND t2.status='READ ONLY')
        LOOP
            exec('ALTER TABLESPACE '||C.tablespace_name||' READ WRITE');
        END LOOP;
    END;

    -------------------------------
    PROCEDURE set_ts_readonly IS
    /*
     *  SET APPLICATION TABLESPACES TO READ ONLY. PRESERVE PRE_MIGRATION STATUS TO BE APPLIED POST MIGRATION.
     */
    BEGIN
        DELETE pre_migration_ts;
        INSERT INTO pre_migration_ts(tablespace_name, status)
        SELECT DISTINCT tablespace_name, status FROM v_app_tablespaces;
        COMMIT;

        FOR C IN (SELECT tablespace_name FROM pre_migration_ts WHERE status='ONLINE')
        LOOP
            exec('ALTER TABLESPACE ' || C.tablespace_name || ' READ ONLY');
        END LOOP;
    END;


    -------------------------------
    PROCEDURE closing_remarks(p_run_mode IN VARCHAR2, p_pw IN VARCHAR2) IS
        l_db_name v$database.name%type;
        l_oracle_pdb_sid VARCHAR2(30);
        l_service_name v$services.name%type;
        l_command VARCHAR2(300);
        l_ip_address VARCHAR2(20);
        l_port VARCHAR2(5):='1521';
        n PLS_INTEGER;
    BEGIN
        l_service_name:=getDefaultServiceName();
        n:=INSTR(l_service_name,'.');
        l_db_name:=CASE WHEN n>0 THEN SUBSTR(l_service_name,1,n-1) ELSE l_service_name END;
        sys.dbms_system.get_env('ORACLE_PDB_SID',l_oracle_pdb_sid);

        SELECT log_message INTO l_ip_address FROM migration_log WHERE name='IP';
                        
        FOR C IN (SELECT NULL FROM dba_objects where owner='PUBLIC' AND object_name='V$LISTENER_NETWORK') LOOP
            EXECUTE IMMEDIATE q'{SELECT REGEXP_SUBSTR(value,'PORT=(\d+)',1,1,'i',1) FROM v$listener_network WHERE type='LOCAL LISTENER'}' INTO l_port;
        END LOOP;

        l_command:='./runMigration.sh -c ' || MIGRSCHEMA||'/'''||p_pw || ''' -t ' || l_ip_address || ':' || l_port || '/' || COALESCE(l_oracle_pdb_sid,l_service_name) || ' -p ' || l_db_name;

        log('PREPARATION TASKS COMPLETED SUCCESSFULLY. LOGON TO TARGET AND RUN','-');
        log('');
        log(l_command,'-');
    END;
    
    -------------------------------
    PROCEDURE create_transfer_directories IS
    /*
     *  CREATE DIRECTORIES FOR REFERENCE BY DBMS_FILE_TRANSFER ON TARGET
     */
    BEGIN
        FOR C IN (SELECT directory_name, ROWNUM rn FROM 
                    ( SELECT DISTINCT SUBSTR(f.file_name,1,INSTR(f.file_name,'/',-1)-1) directory_name
                        FROM dba_tablespaces t, dba_data_files f
                       WHERE t.tablespace_name=f.tablespace_name
                         AND t.contents='PERMANENT'
                         AND t.tablespace_name NOT IN ('SYSTEM','SYSAUX')
                    )
        ) LOOP
            exec('CREATE OR REPLACE DIRECTORY '|| MIGRSCHEMA ||'_FILES_'||C.rn||'_DIR AS '''||C.directory_name||'''');
        END LOOP;
    END;

    --------------------------------------------------
    PROCEDURE init (p_run_mode IN VARCHAR2, p_pw IN VARCHAR2, p_bkpdir IN VARCHAR2) IS
        l_compatibility VARCHAR2(50);
        l_version VARCHAR2(50);
        l_dbtimezone VARCHAR2(50);
    BEGIN
        SELECT MAX(REGEXP_SUBSTR(banner,'\d+.\d+.\d+.\d+')) INTO l_version FROM v$version;
        SELECT RTRIM(value) INTO l_compatibility FROM v$parameter WHERE name='compatible';

        CASE p_run_mode
            WHEN 'ANALYZE' THEN
                check_tts_set;
                log_details(p_run_mode, l_version, l_compatibility, p_bkpdir);
            WHEN 'EXECUTE' THEN
                FOR C IN (SELECT DISTINCT ts_name, owner FROM dba_recyclebin WHERE ts_name IS NOT NULL AND ts_name NOT IN ('SYSTEM','SYSAUX')) LOOP
                    exec('PURGE TABLESPACE '||C.ts_name||' USER '||C.owner);
                END LOOP;
                check_tts_set;
                IF (p_bkpdir IS NULL) THEN
                    set_ts_readonly;
                    create_transfer_directories;
                ELSE
                    exec('CREATE OR REPLACE DIRECTORY '||MIGRSCHEMA||'_FILES_1_DIR AS '''||p_bkpdir||'''');
                    SELECT dbtimezone INTO l_dbtimezone FROM dual;
                    dbms_scheduler.purge_log(job_name=>'INCREMENTAL_BACKUP');
                    dbms_scheduler.create_job(
                        job_name=>'INCREMENTAL_BACKUP',
                        job_type=>'PLSQL_BLOCK',
                        start_date=>TO_TIMESTAMP_TZ(TO_CHAR(SYSTIMESTAMP, 'DDMMYYYY HH24:MI:SS')||' '||l_dbtimezone, 'DDMMYYYY HH24:MI:SS TZR'),
                        job_action=>'BEGIN pck_migration_src.incremental_backup; END;',
                        enabled=>TRUE);
                    dbms_scheduler.set_attribute(name=>'INCREMENTAL_BACKUP', attribute=>'RESTARTABLE', value=>TRUE);                        
                END IF;
                closing_remarks(p_run_mode, p_pw);
        END CASE;

        EXCEPTION WHEN TTS_CHECK_FAILED THEN
            RAISE_APPLICATION_ERROR(-20000,'TTS_CHECK_FAILED');

    END;
END;
/