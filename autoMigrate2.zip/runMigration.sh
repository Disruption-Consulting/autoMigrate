#!/bin/bash

#####################################################################################################################################
#
#  SCRIPT        : runMigration.sh
#
#  DESCRIPTION   : Migrates a NON-CDB Oracle database (SOURCE) to version 19 PDB (TARGET)
#
#  INSTALL       : Install this script and relevant package sql files in an installation directory (e.g. "/tmp/migrate")
#
#
#  SOURCE DATABASE
#                       
#                ./runMigration -u [USER] -o [ORACLE_SID] -r
#
#                -o ORACLE_SID
#                     identifies the SOURCE Oracle database to be migrated. Only use if multiple databases running on this host.
#
#                -r removes the schema created to manage the migration and any incremental backups
#
#                -u USER
#                     required only if pre-migration database happens to have a user called "MIGRATION19"
#
#                OUTPUT
#                  log file "runMigration.${ORACLE_SID}.log"
#                   
#
#  TARGET DATABASE
#                       
#                ./runMigration -n [EZCONNECT] -p [PDB} -o [ORACLE_SID] -r
#
#                -n EZCONNECT
#                     EZCONNECT string defining location of source database, i.e. HOST:PORT/SERVICE where SERVICE=DB_NAME.DB_DOMAIN
#
#                -p PDB
#                     Name of the PDB to be created. Default is DB_NAME in EZCONNET string.
#
#                -o ORACLE_SID
#                     identifies the TARGET CDB database for the migration. Only use if multiple databases running on this host.
#
#                -r removes the named PDB permanently including any data files
# 
#                OUTPUT
#                  log file "runMigration.${PDB}.log" - tasks performed to create the target PDB
#
#####################################################################################################################################


usageSource() {
    echo "Usage: $0 [ - u USER ]"
    exit 1
}

usageTarget() {
    echo "Usage: $0 -n HOST:PORT/SERVICE [ -p PDB ]"
    exit 1
}

upper() {
    local UPPER=$(echo "${1}" | tr '[:lower:]' '[:upper:]')
    echo ${UPPER}
}

password() {
    local PW=$(cat /dev/urandom | tr -cd "a-zA-Z0-9@#%^*()_+?><~\`;" | head -c 10)
    echo \"${PW}\"
}

version() {
    local a b c d V="$@"
    IFS=. read -r a b c d <<< "${V}"
    echo "$((a * 10 ** 3 + b * 10 ** 2 + c * 10 + d))"
}

log() {
    echo -e "${1//?/${2:-=}}\n$1\n${1//?/${2:-=}}";
}


chkerr() {
    [[ "$1" != 0 ]] && { echo -n "ERROR at line ${2}: "; echo "${3}"; exit 1; }
}

#################################################################################
#
#  function: runsql
#
#  - run either the SQL passed in "-s" argument OR in file ${SQLFILE}
#  - "-v" argument returns result to STDOUT enabling ot to be captured in variable 
#  - default CONNECT string only applies for "-s"
#################################################################################
runsql() {
    local OPTIND
    local SQL
    local RETVAL=FALSE
    local SILENT
    
    while getopts "s:v" o; do
        case "${o}" in
            s) SQL=${OPTARG} ;;
            v) RETVAL=TRUE ;;
        esac
    done
    
    if [ -n "${SQL}" ]; then
        echo -e "CONNECT / AS SYSDBA\n${SQL}">${SQLFILE}
    fi
    
    if [ "${RETVAL}" = "FALSE" ]; then
        echo -e "WHENEVER SQLERROR EXIT FAILURE\nSET ECHO ON\n$(cat ${SQLFILE})\nCOMMIT;\nEXIT" > ${SQLFILE}
    else
        echo -e "WHENEVER SQLERROR EXIT FAILURE\nSET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF\n$(cat ${SQLFILE})\nCOMMIT;\nEXIT" > ${SQLFILE}
        SILENT="-silent"
    fi    
    
    sqlplus ${SILENT} /nolog @${SQLFILE} || { return 1; }
}


#################################################################################
#
#  function: createWallet
#
#  - create wallet for external password store. 
#  - store randomly generated wallet password in global variable WPW
#  - configure sqlnet.ora to enable use of External password store
#################################################################################
createWallet() {
    log "createWallet - ${WALLET}" 
    
    WPW=$(password)
    mkstore -wrl "${WALLET}" -create<<-EOF
${WPW}
${WPW}
EOF
    [[ $? != 0 ]] && { echo "ERROR CREATING WALLET"; exit 1; }
    
    echo "${WPW}">"${TNS_ADMIN}/.wallet"
    
    cat <<EOF>${SQLNET}
WALLET_LOCATION = (SOURCE = (METHOD = FILE)(METHOD_DATA =(DIRECTORY = ${WALLET})))
SQLNET.WALLET_OVERRIDE = TRUE
EOF
}


#################################################################################
#
#  function: createCredential
#
#  - append entry for credential in tnsnames.ora
#  - when credential has alias $ORACLE_SID set CONNECT global variable
#################################################################################
createCredential() {
    log "createCredential - ALIAS:${1} USER: ${2} SERVICE: ${4}"
    
    local TNS="${1}"
    local USR="${2}"
    local PWD="${3}"
    local SVC="${4}"
    
    mkstore -wrl "${WALLET}" -createCredential "${TNS}" "${USR}" "${PWD}"<<EOF
${WPW}
EOF
    [[ $? != 0 ]] && { echo "ERROR CREATING CREDENTIAL"; exit 1; }

    log "Add entry for ${TNS} to ${TNSNAMES}"
    cat <<EOF>>${TNSNAMES}
${TNS}=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=${SVC})))
EOF

    # Reset CONNECT string to use Wallet as soon as credential for ORACLE_SID created
    #
    [[ "${TNS}" = "${ORACLE_SID}" ]] && CONNECT="/@${TNS}"
}


#################################################################################
#
#  function: deleteCredential
#
#  - delete credential from wallet
#  - remove entry for credential from tnsnames.ora
#################################################################################
deleteCredential() {
    log "deleteCredential - ${1}"
    
    local TNS="${1}"
    
    mkstore -wrl "${WALLET}" -deleteCredential "${TNS}"<<EOF
${WPW}
EOF
    [[ $? != 0 ]] && { echo "ERROR DELETING CREDENTIAL"; exit 1; }
    
    sed -i "/^${TNS}/d" ${TNSNAMES}
}

#################################################################################
#
#  function: getPW
#
#  - retrieve USER password from wallet
#################################################################################
getPW() {
    local WALLET_TMP="${TNS_ADMIN}/wallet.tmp"
    mkstore -wrl "${WALLET}" -listCredential -nologo>"${WALLET_TMP}"<<EOF
${WPW}
EOF

    local N=$(tail -n +3 "${WALLET_TMP}"| awk -F" " -v U="${USER}" '$3 == U { print $1 }'| cut -d ":" -f1); rm "${WALLET_TMP}"

    local PW=$(mkstore -wrl "${WALLET}" -viewEntry oracle.security.client.password${N} -nologo<<EOF
${WPW}
EOF
)
    PW=$(echo ${PW}|awk -F'= ' '{ print $2}')
    
    echo ${PW} 
}
    

#################################################################################
# Remove objects created to enable autoMigration on SOURCE database
#
# - restore tablespace pre-migration status
# - drop the schema - default name is MIGRATION19
# - drop directories created with name like MIGRATION19
# - remove wallet and its enabling network configuration files
#################################################################################
removeSource() {
    log "removeSource"
    
    cat <<-EOF>${SQLFILE}
        CONNECT / AS SYSDBA
        WHENEVER SQLERROR EXIT FAILURE
        SET SERVEROUTPUT ON
        SET ECHO ON
        EXEC ${USER}.pck_migration_noncdb.set_ts_readwrite
        DROP USER ${USER} CASCADE;
        DECLARE
            PROCEDURE exec(pCommand IN VARCHAR2) IS
            BEGIN
                dbms_output.put(pCommand);
                EXECUTE IMMEDIATE pCommand;
                dbms_output.put_line(' ..OK');
                EXCEPTION WHEN OTHERS THEN
                    dbms_output.put_line(' ..FAILED');
                    RAISE;
            END;
        BEGIN
            FOR C IN (SELECT directory_name FROM dba_directories WHERE directory_name LIKE '${USER}_%_DIR') LOOP
                exec('DROP DIRECTORY '||C.directory_name);
            END LOOP;
        END;
        /
EOF
    runsql || { echo "SQL FAILED"; exit 1; }
}


createSourceSchema(){
    log "createSourceSchema"
    
    [[ -z "${TNS_ADMIN}" ]] && local TNS_ADMIN=${ORACLE_HOME}/network/admin

    cat <<-EOF>${SQLFILE}
        CONNECT / AS SYSDBA
        
        WHENEVER SQLERROR CONTINUE
        DROP USER ${USER} CASCADE;       
        
        WHENEVER SQLERROR EXIT FAILURE
        
        set linesize 150
        set serveroutput on
        
        set feedback off
        set echo off
        @@migration19.plb
        variable pw varchar2(12)
        EXEC :pw:=migration19
        DROP FUNCTION migration19;
        set echo on
        set feedback on
        
        EXEC EXECUTE IMMEDIATE 'CREATE USER ${USER} IDENTIFIED BY '||:pw||' DEFAULT TABLESPACE SYSTEM QUOTA 10M ON SYSTEM';
        
        GRANT SELECT ANY DICTIONARY,
              CREATE SESSION,
              ALTER TABLESPACE,
              ANALYZE ANY,
              CREATE ANY JOB,
              CREATE ANY DIRECTORY,
              MANAGE SCHEDULER,
              DATAPUMP_EXP_FULL_DATABASE TO ${USER};
              
        GRANT EXECUTE ON SYS.DBMS_BACKUP_RESTORE TO ${USER};
        GRANT EXECUTE ON SYS.DBMS_SYSTEM TO ${USER};
        GRANT EXECUTE ON SYS.DBMS_STATS TO ${USER};

        CREATE OR REPLACE DIRECTORY ${USER}_TNS_ADMIN AS '${TNS_ADMIN}';
        GRANT READ, WRITE ON DIRECTORY ${USER}_TNS_ADMIN TO ${USER};
        
        CREATE OR REPLACE DIRECTORY ${USER}_SCRIPT_DIR AS '${CD}';
        GRANT READ, WRITE ON DIRECTORY ${USER}_SCRIPT_DIR TO ${USER};        
        
        ALTER SESSION SET CURRENT_SCHEMA=${USER};
        
        CREATE OR REPLACE VIEW V_APP_TABLESPACES AS
            SELECT t.tablespace_name, t.status, f.file_id, f.file_name, f.bytes
              FROM dba_tablespaces t, dba_data_files f
             WHERE t.tablespace_name=f.tablespace_name
               AND t.contents='PERMANENT'
               AND t.tablespace_name NOT IN ('SYSTEM','SYSAUX');
            
        CREATE TABLE pre_migration_ts(
            tablespace_name VARCHAR2(30),
            status VARCHAR2(10));
            
        CREATE TABLE properties(
            name VARCHAR2(50),
            value VARCHAR2(2000),
            description VARCHAR2(200),
            contents CLOB);
                    
        CREATE SEQUENCE migration_log_seq START WITH 1 INCREMENT BY 1;

        CREATE TABLE migration_log(
            id NUMBER,
            name VARCHAR2(10),
            log_time DATE DEFAULT SYSDATE,
            log_message CLOB,
            CONSTRAINT PK_MIGRATION_LOG PRIMARY KEY(id));
            
        EXEC DBMS_STATS.CREATE_STAT_TABLE (ownname => '${USER}', stattab => 'DBMS_STATS_TABLE');
EOF
    
    cat <<-EOF>>${SQLFILE}
    PROMPT "COMPILING pck_migration_noncdb"
    set echo off
    @@pck_migration_noncdb.sql
    set echo on
    show errors
    BEGIN
        EXECUTE IMMEDIATE 'ALTER PACKAGE pck_migration_noncdb COMPILE';
        EXCEPTION WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20000,'COMPILE FAILED');
    END;
    /
    
    EXEC ${USER}.pck_migration_noncdb.log_details
    
    ALTER SESSION SET CURRENT_SCHEMA=SYS;
    EXEC EXECUTE IMMEDIATE 'CREATE DATABASE LINK ${USER} CONNECT TO ${USER} IDENTIFIED BY '||:pw||' USING ''3618fb7561ac:1521/NONCDB12.cis.cat.com'''; 
    ALTER SESSION SET GLOBAL_NAMES=FALSE;
    DELETE properties@${USER} WHERE global_name=(SELECT global_name FROM global_name);
    INSERT INTO properties@${USER}(global_name, name, value, contents, description) SELECT global_name, name, value, contents, description FROM ${USER}.properties, global_name;
    COMMIT;
    DROP DATABASE LINK ${USER};
     
     
    set echo off
    PROMPT *****************************************
    PROMPT SCHEMA ${USER} INSTALLED SUCCESSFULLY
    PROMPT *****************************************
EOF
    
    runsql || { echo "createSourceSchema FAILED"; exit 1; }
}


processSource() {
    log "processSource"
    
    cat <<-EOF>${SQLFILE}
    CONNECT / AS SYSDBA
    SET SERVEROUTPUT ON
    SET ECHO OFF
    DECLARE
        n PLS_INTEGER;
    BEGIN
        n:=0;
        FOR C IN (SELECT DISTINCT file_name,nb,GT2TB FROM 
                    (SELECT file_name,COUNT(*) OVER (PARTITION BY file_name) nb, CASE WHEN bytes>2*POWER(1024,4) THEN 1 ELSE 0 END GT2TB
                       FROM(
                          SELECT SUBSTR(f.file_name,INSTR(f.file_name,'/',-1)+1) file_name, bytes
                            FROM dba_tablespaces t, dba_data_files f
                           WHERE t.tablespace_name=f.tablespace_name
                             AND t.contents='PERMANENT'
                             AND t.tablespace_name NOT IN ('SYSTEM','SYSAUX')
                        )
                 ) ) 
        LOOP
            IF (C.nb>1) THEN
                n:=n+1;
                dbms_output.put_line(C.file_name||' IN MULTIPLE DIRECTORIES. MUST BE RENAMED TO BE UNIQUE WITHIN DATABASE.');
            END IF;
            IF (C.GT2TB>0) THEN
                n:=n+1;
                dbms_output.put_line(C.file_name||' EXCEEDS MAXIMUM SIZE ALLLOWED 2TB.');
            END IF;
        END LOOP;    
        
        IF (n>0) THEN
            RAISE_APPLICATION_ERROR(-20000,n||' QUALIFICATION ERROR(S) OCCURED');
        END IF;
    END;
    /
EOF
    runsql || { echo "DATABASE DOES NOT QUALIFY FOR MIGRATION WITH THIS UTILITY"; exit 1; }    
    
    
    [[ "${REMOVE}" = "TRUE" ]] && { removeSource; exit 0; } || createSourceSchema
}



#################################
#
#    TARGET MIGRATION PROCESS
#
#################################


removeTarget() {
    log "removeTarget"
    
    local FILEPATH=$(runsql -v -s "SELECT MAX(SUBSTR(f.file_name,1,INSTR(f.file_name,'/',-1))) FROM cdb_data_files f, v\$pdbs p WHERE f.con_id=p.con_id AND p.name='${PDB}';");
    chkerr "$?" "${LINENO}" "${FILEPATH}"
    
    [[ -z "${FILEPATH}" ]] && { echo "NO FILEPATH FOR ${PDB}. EXIT IMMEDIATELY."; exit 1; }
    
    cat <<-EOF>${SQLFILE}
        CONNECT ${CONNECT} AS SYSDBA
        WHENEVER SQLERROR CONTINUE
        ALTER PLUGGABLE DATABASE ${PDB} CLOSE IMMEDIATE;
        WHENEVER SQLERROR EXIT FAILURE
        DROP PLUGGABLE DATABASE ${PDB} INCLUDING DATAFILES;
        
        PROMPT FILES REMAINING IN PDB DIRECTORY AFTER SUCCESSFUL DROP
        HOST ls -ltr "${FILEPATH}"
        
        BEGIN
            FOR C IN (SELECT job_name FROM dba_scheduler_jobs WHERE job_name LIKE '%${PDB}') LOOP
                DBMS_SCHEDULER.DROP_JOB(C.job_name);
            END LOOP;
        END;
        /
EOF
    runsql || { echo "removeTarget FAILED"; exit 1; }
    
    deleteCredential "${PDB}"
}


validateTarget() {
    log "validateTarget"
    
    cat <<-EOF>${SQLFILE}
        CONNECT / AS SYSDBA
        WHENEVER SQLERROR CONTINUE
        DROP DATABASE LINK MIGR_DBLINK_${PDB};
        WHENEVER SQLERROR EXIT FAILURE
        
        set echo off
        @@migration19.plb
        set echo on
        
        EXEC EXECUTE IMMEDIATE q'{CREATE DATABASE LINK ${PDB} CONNECT TO ${USER} IDENTIFIED BY }'||migration19||q'{ USING '${EZCONNECT}'}';
        
        DROP FUNCTION migration19;
        
        DECLARE
            l_mismatch VARCHAR2(200):=NULL;
        BEGIN
            /*
             *  CHECK SOURCE AND TARGET CHARACTERSETS ARE THE SAME.
             */        
            FOR C IN (
                SELECT COUNT(src) src, COUNT(tgt) tgt, property_name, property_value
                FROM
                (
                SELECT 1 tgt, TO_NUMBER(NULL) src, property_name, property_value 
                FROM database_properties WHERE property_name IN ('NLS_CHARACTERSET','NLS_NCHAR_CHARACTERSET')
                UNION ALL
                SELECT TO_NUMBER(NULL) tgt, 1 src, property_name, property_value 
                FROM database_properties@${PDB} WHERE property_name IN ('NLS_CHARACTERSET','NLS_NCHAR_CHARACTERSET')
                )
                GROUP BY property_name, property_value
                ) 
            LOOP
                IF (C.tgt=1 AND C.src=1) THEN
                    CONTINUE;
                END IF;
                IF (C.src=1) THEN
                    l_mismatch:=l_mismatch||' SOURCE '||C.property_name||':'||C.property_value;
                ELSE
                    l_mismatch:=l_mismatch||' TARGET '||C.property_name||':'||C.property_value;
                END IF;
            END LOOP;
            IF (l_mismatch IS NOT NULL) THEN
                RAISE_APPLICATION_ERROR(-20000,'CHARACTER SET MISMATCH. MUST FIRST MIGRATE TO INTERIM CDB WITH SAME CHARACTERSET AND THEN RELOCATE TO FINAL AL32UTF8 CDB - '||l_mismatch);
            END IF;
        END;
        /
        
        DROP DATABASE LINK ${PDB};
EOF
    runsql || { echo "MIGRATION STOPPED. RESOLVE ISSUE AND RETRY."; exit 1; } 
}


createTargetPdb() {
    log "createTargetPdb"
    
    local PW=$(password)
    
    cat <<-EOF>${SQLFILE}
        CONNECT / AS SYSDBA
        CREATE PLUGGABLE DATABASE ${PDB} ADMIN USER PDBADMIN IDENTIFIED BY ${PW} ROLES=(DATAPUMP_IMP_FULL_DATABASE) FILE_NAME_CONVERT=('pdbseed','${PDB}');

        ALTER SESSION SET CONTAINER=${PDB};
        
        ALTER PLUGGABLE DATABASE ${PDB} OPEN READ WRITE;
        ALTER PLUGGABLE DATABASE ${PDB} SAVE STATE;
        AUDIT CONNECT;
        ALTER USER PDBADMIN QUOTA UNLIMITED ON SYSTEM;
        GRANT ALTER SESSION,
              ALTER TABLESPACE,
              ANALYZE ANY,
              ANALYZE ANY DICTIONARY,
              CREATE ANY DIRECTORY,
              CREATE JOB,
              CREATE PUBLIC DATABASE LINK,
              CREATE SESSION,
              CREATE TABLESPACE,
              DROP TABLESPACE,
              DROP ANY DIRECTORY,
              SELECT ANY DICTIONARY TO PDBADMIN;
              
        CREATE DIRECTORY MIGRATION_SCRIPT_DIR AS '${CD}';
        GRANT READ, WRITE ON DIRECTORY MIGRATION_SCRIPT_DIR TO PDBADMIN;
        
        COL filepath NEW_VALUE filepath noprint;
        SELECT MAX(SUBSTR(file_name,1,INSTR(file_name,'/',-1)-1)) AS filepath FROM cdb_data_files WHERE con_id=SYS_CONTEXT('USERENV','CON_ID');

        CREATE SEQUENCE PDBADMIN.migration_log_seq START WITH 1 INCREMENT BY 1;
        CREATE TABLE PDBADMIN.migration_log
                       ("ID"            NUMBER DEFAULT PDBADMIN.migration_log_seq.NEXTVAL,
                        "LOG_TIME"      DATE DEFAULT SYSDATE,
                        "LOG_MESSAGE"   CLOB,
                        CONSTRAINT PK_MIGRATION_LOG PRIMARY KEY(id));
                        
        CREATE PUBLIC DATABASE LINK MIGR_DBLINK CONNECT TO ${USER} IDENTIFIED BY ${DBLINKPWD} USING '${TNS}';
        CONNECT ${CONNECT}
        CREATE OR REPLACE DIRECTORY TGT_FILES_DIR_${PDB} AS '&filepath';
EOF
    runsql || { echo "createTargetPdb FAILED"; exit 1; }
    
    createCredential "${PDB}" "PDBADMIN" "${PW}" "${PDB}" 
}


createTargetRunScripts() {
    log "createTargetRunScripts"
    
    local RUNSCRIPT="${1}"
    
    cat <<-EOF>${RUNSCRIPT}.sql
        whenever sqlerror exit failure
        set echo on
        set serveroutput on
        set linesize 300
        variable n number
        connect ${CONNECT}
        begin
            insert into migration_log(pdb_name,name,log_message) VALUES ('${PDB}','STATUS','TRANSFER');
            :n:=pck_migration_cdb.transfer(pPdbname=>'${PDB}',pEndDate=>'${ENDDATE}');
            dbms_output.put_line('pck_migration_cdb.transfer(${PDB}):'||:n);
        end;
        /
        connect ${CONNECT} AS SYSDBA
        begin
            if (:n>0) then
                dbms_scheduler.set_attribute(name=>'MIGRATION_${PDB}',attribute=>'repeat_interval',value=>'freq=hourly');
            end if;
        end;
        /        
        connect /@${PDB}
        begin
            if (:n=0) then
                insert into migration_log@migr_dblink_cdb(pdb_name,name,log_message) VALUES ('${PDB}','STATUS','DATAPUMP');
                pck_migration_pdb.impdp(pOverride=>${OVERRIDE},pDbmsStats=>${DBMSSTATS});
            end if;
        end;
        /
        exit
EOF

    cat /dev/null>${RUNSCRIPT}.impdp.sh
    
    cat <<-EOF>${RUNSCRIPT}.sh
#!/bin/bash
exec 1>${RUNSCRIPT}.log 2>&1
export ORACLE_HOME=${ORACLE_HOME}
export ORACLE_SID=${ORACLE_SID}
export PATH=\${ORACLE_HOME}/bin:${PATH}
export TNS_ADMIN=${CD}

sqlplus /nolog @${RUNSCRIPT}.sql
[[ \$? = 0 ]] && { echo "TRANSFER COMPLETED"; } || { echo "FAILED TO RUN ${RUNSCRIPT}.sql"; exit 1; }

. ${RUNSCRIPT}.impdp.sh

exit 0
EOF
    chmod u+x ${RUNSCRIPT}.sh    
}


runTargetMigration() {
    log "runTargetMigration"
    
    local RUNSCRIPT="${CD}/${FN}.${PDB}"
    
    createTargetRunScripts "${RUNSCRIPT}"

    cat <<-EOF>${SQLFILE}        
        CONNECT ${CONNECT} AS SYSDBA
        
        DECLARE
            l_dbtimezone VARCHAR2(50);
        BEGIN 
            SELECT dbtimezone INTO l_dbtimezone FROM dual;
            DBMS_SCHEDULER.CREATE_JOB(
                job_name=>'MIGRATION_${PDB}',
                job_type=>'EXECUTABLE',
                start_date=>TO_TIMESTAMP_TZ(TO_CHAR(SYSTIMESTAMP, 'DDMMYYYY HH24:MI:SS')||' '||l_dbtimezone, 'DDMMYYYY HH24:MI:SS TZR'),
                enabled=>TRUE,
                job_action=>'${RUNSCRIPT}.sh');
        END;
        /
EOF
    runsql || { echo "runTargetMigration FAILED"; exit 1; }
}


processTarget() {
    log "processTarget"
    
    # Create wallet network config files if not exists
    #
    export TNS_ADMIN="${CD}"
    TNSNAMES="${TNS_ADMIN}/tnsnames.ora"; [[ -f "${TNSNAMES}" ]] || cat /dev/null>"${TNSNAMES}"
    SQLNET="${TNS_ADMIN}/sqlnet.ora"; [[ -f "${SQLNET}" ]] || cat /dev/null>"${SQLNET}"
    WALLET="${TNS_ADMIN}/wallet"; [[ -d "${WALLET}" ]] && WPW=$(<"${TNS_ADMIN}/.wallet") || createWallet
    
    local EXISTS="0"
    
    EXISTS=$(runsql -v -s "SELECT TO_CHAR(COUNT(*)) FROM dual WHERE EXISTS (SELECT 1 FROM cdb_pdbs WHERE pdb_name='${PDB}');")
    chkerr "$?" "${LINENO}" "${EXISTS}"
    
    [[ "${REMOVE}" = "FALSE"  && -z "${EZCONNECT}" ]] && { echo "ARGUMENT IDENTIFYING NONCDB MISSING"; usageTarget; exit 1; }
    [[ "${REMOVE}" = "FALSE"  && "${EXISTS}" = "1" ]] && { log "RESTARTING MIGRATION"; runTargetMigration; }
    [[ "${REMOVE}" = "FALSE"  && "${EXISTS}" = "0" ]] && { validateTarget; createTargetPdb; runTargetMigration; }
    
    [[ "${REMOVE}" = "TRUE"  &&  "${EXISTS}" = "0" ]] && { echo "PDB DOES NOT EXIST."; exit 1; }
    [[ "${REMOVE}" = "TRUE" ]] && { removeTarget; }
}

##########################
#   SCRIPT STARTS HERE   #
##########################

SCRIPT=$(basename $0); FN="${SCRIPT%.*}"; SQLFILE=${FN}.sql; CD=$(pwd)

USER=MIGRATION19

unset EZCONNECT
unset PDB
unset REMOVE
unset DBMSSTATS

while getopts "::n:o:p:s:urh" o; do
    case "${o}" in
        n) EZCONNECT=${OPTARG}; PDB=$(echo "${EZCONNECT}"|cut -d'/' -f2|cut -d'.' -f1); ;;
        o) ORACLE_SID=${OPTARG}; ORAENV_ASK=NO; . oraenv ;;
        p) PDB=$(upper ${OPTARG}) ;;
        r) REMOVE=TRUE ;;
        s) DBMSSTATS=$(upper ${OPTARG}) ;;
        u) USER=${OPTARG} ;;
        h) usageTarget ;;
        :) echo "ERROR -${OPTARG} REQUIRES  ARGUMENT"; usageTarget ;;
        *) usageTarget ;;
    esac
done

[[ -z "${PDB}" ]] && LOGFILE=${FN}.${ORACLE_SID}.log || LOGFILE=${FN}.${PDB}.log

exec > >(tee ${LOGFILE}) 2>&1

# Confirm ORACLE_SID is running
#
DBUP=$(ps -ef | grep -v grep | grep pmon_${ORACLE_SID} | wc -l)
[[ "${DBUP}" = "0" ]] && { echo "${ORACLE_SID} NOT RUNNING ON THIS SERVER"; exit 1; }

# Get database version and determine if database is CDB
#
VERSION=$(runsql -v -s "SELECT MAX(REGEXP_SUBSTR(banner,'\d+.\d+.\d+.\d+')) FROM v\$version;")
chkerr "$?" "${LINENO}" "${VERSION}"

CDB=NO
[[ ${VERSION} = 19* ]] && { CDB=$(runsql -v -s "SELECT cdb FROM v\$database;"); chkerr "$?" "${LINENO}" "${CDB}"; }

# CDB=YES means we are TARGET 19 else SOURCE 12.2
#
case "${CDB}" in
    NO)
        [[ -z "${REMOVE}" ]] && REMOVE=FALSE
        processSource
        ;;
    YES)
        [[ -z "${DBMSSTATS}" ]] && DBMSSTATS=TRUE
        [[ -z "${REMOVE}" ]] && REMOVE=FALSE
        processTarget
        ;;
esac

exit 0